<?php
//Database Configuration

$mysqli = mysqli_connect("localhost", "root", "","tracking") or die ("Database Error");

$getData = $_GET['term'];
$query = $mysqli -> query ("SELECT doctor_name FROM doctor_details WHERE doctor_name LIKE '%".$getData."%'");
while ($row = $query -> fetch_assoc()){
$data[] = $row['doctor_name'];
}
echo json_encode($data);

?>