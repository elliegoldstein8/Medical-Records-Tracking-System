<?php 	
include('session.php');
	?>
<?php include('functions.php');
	
 $db = mysqli_connect("localhost", "root", "", "tracking");
 $query = "SELECT * FROM deficiency_patient_details";
 $result = mysqli_query($db, $query);
 $status="";
?>
<!DOCTYPE html>
<html>
<head>
<script src="js/jquery.min.js"></script>
 <script language="JavaScript"  src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
 <link rel= "stylesheet" href = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
 
 <script src = "https://code.jquery.com/jquery-1.12.4.js"> </script>
 <script src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


    <script  src="js/index.js"></script>
	

<script>
  $(function(){
   $("#doctor_input").autocomplete({
   source: 'searchdoctor.php',
  });
  });
  </script>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
.btn {
  color: #fff;
  background-color: #97EBB4;
  padding: .8rem;
  font-size: 1.2rem;
  line-height: 1.2rem;
  border-radius: 5px;
  border: 2px solid transparent;
  min-width: 45px !important;
}
</style>
</head>
<body>
	
<?php $dhatz = '2787zzzjhsjhxjhcjhuyueryeyruyu';?>	
<div class="topnav">
  <a class="active" href="reg">Encode</a>
  <a href="reports1">Report</a>
   <a href="deficiencyList">Deficiency</a>
		  <a href="patientList">Patient List</a>
		   <a href="settings1">Settings</a>
    <a href="logout.php" style="float:right;background-color:red">Logout</a>

</div>

<script type="text/javascript">
$(document).ready(function(){    
    //Check if the current URL contains '#'
    if(document.URL.indexOf("#")==-1){
        // Set the URL to whatever it was plus "#".
        url = document.URL+"#";
        location = "#";

        //Reload the page
        location.reload(true);
    }
});
</script>

</body>
</html>

 
<html>

<head>

<center>
<h2>Generate Reports</h2>
<h3>Search by Doctor</h3>

<form method="GET" action="DoctorReport.php?<?php echo $_GET['doctor_input'] + $_GET['doctor_date'] + $_GET['doctor_dateu']; ?>" >
					<input id="doctor_input" name = "doctor_input" oninvalid="this.setCustomValidity('Please Enter Doctor`s Name')" oninput="setCustomValidity('')" style="font-size: 18px; height: 40px; width: 350px;" type="text" placeholder="Enter Doctor Name"  required/>

 </p>
 
 <h4> From: </h4>

  <p>
 <p>
			<input type= "date" class = "date-group" name = "doctor_date"
				style = "width: 350px;padding-top: -850px; font-size: 18px;"oninvalid="this.setCustomValidity('Please Input Start Date')" oninput="setCustomValidity('')"  required>
 </p>
 <h4> To: </h4>

  <p>
			<input type= "date" class = "date-group" name = "doctor_dateu" oninvalid="this.setCustomValidity('Please Input End Date')" oninput="setCustomValidity('')" 
				style = "width: 350px;padding-top: -850px; font-size: 18px;" required>
 </p>

 <div class="buttons">

						<button type="submit" style = "margin-left:200px;background-color:green;cursor:pointer" class="btn">Continue</button>
				</div>
					</form>

  </div>
  <br><br>
	<h3 style = "padding-top: 0px;">Overall Report</h3>
	 <h4> From: </h4>

 <p>
 <form method="GET" action="Monthly.php?<?php echo $_GET['monthly_date'] + $_GET['doctor_date'] ; ?>" >
<input type= "date" class = "date-group" name = "monthly_date" style = "width: 350px;padding-top: -850px; font-size: 18px;" oninvalid="this.setCustomValidity('Please Input Start Date')" oninput="setCustomValidity('')" required> </p>
  <h4> To: </h4>
  <p>
<input type= "date" class = "date-group" name = "doctor_date" style = "width: 350px;padding-top: -850px; font-size: 18px;" oninvalid="this.setCustomValidity('Please Input End Date')" oninput="setCustomValidity('')" style = "width: 350px;padding-top: 30px; font-size: 18px;" required>
 </p>
 <div class="buttons">
<button type="submit" style = "margin-left: 200px;background-color:green;cursor:pointer;" class="btn">Continue</button>
</div>
</form>
</center>


</body>
</html>
