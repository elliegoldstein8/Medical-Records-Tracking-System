<?php
  $conn = new mysqli('localhost','root','','tracking');
  
if(ISSET($_POST['btnSubmits'])){
	
	date_default_timezone_set('Asia/Manila');
	
	$date = date('Y-m-d');
	$patient = mysqli_real_escape_string($conn,$_POST['patient']);
	$patientNo = mysqli_real_escape_string($conn,$_POST['patientNo']);
	$date = $_POST['date'];
	
	$sql = $conn->query("select * from patient_details where hosp_patient_no = '$patientNo' ") or die ("could not connect to mysql");
	 $rowD = $sql->fetch_array();
	$hNo =mysqli_real_escape_string($conn,$rowD['hosp_patient_no']);
	


if($hNo==$patientNo){	
	

$conn->query("update deficiency_patient_details set hosp_patient_no = '$patientNo',date = '$date' where hosp_patient_no = '' and date = '0000-00-00' ");

echo "<script>alert('Successfully Added');window.location='reg.php'</script>";	
}else{
		$conn->query("insert into patient_details(hosp_patient_no,patient_name)values('$patientNo','$patient')");
		
		$conn->query("update deficiency_patient_details set hosp_patient_no = '$patientNo',date = '$date' where hosp_patient_no = '' and date = '0000-00-00' ");

echo "<script>alert('Successfully Added');window.location='reg.php'</script>";	
		
	}


}