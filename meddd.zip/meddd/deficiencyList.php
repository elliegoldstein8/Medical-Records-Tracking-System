<?php
	include('session.php');
 $conn = mysqli_connect("localhost", "root", "", "tracking");
$conn->query("delete from tbl_session_transaction");
?>
<!DOCTYPE html>
<html>
<head>
<script src="js/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>
	
<div class="topnav">
  <a class="active" href="reg">Encode</a>
  <a href="reports1">Report</a>
   <a href="deficiencyList">Deficiency</a>
		  <a href="patientList">Patient List</a>
		   <a href="settings1">Settings</a>
    <a href="logout.php" style="float:right;background-color:red">Logout</a>
</div>

</body>
</html>

  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
 
   <script language="JavaScript"  src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
 <link rel= "stylesheet" href = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
 
<html>
<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<head>

<h2>Deficiency List</h2>
 
<input id="myInput" type="text" placeholder="Search.." style="margin-left:100px;height:30px;width:400px;">
<br><br>

<table>
  <thead>
  <tr>
    <th>#</th>
    <th>Deficiency Name</th>
    <th>Manage</th>
  </tr>
  </thead>
  <tbody id="myTable">
  <?php 
  $x=1;
  $sql =$conn->query("select * from deficiency");

while($row=$sql->fetch_array()){ 
$id =$row['deficiency_id'];

 ?>
  <tr>
    <td><?php  echo $x++; ?></td>
    <td><?php  echo $row['deficiency_name']; ?></td>
    <td><a href ="defRemove.php<?php echo '?id='.$id; ?>" onclick="return confirm('Do you want to delete this Deficiency?');"><?php if($row['deficiency_id']<='15'){ echo "";}else{ ?><img src="img/delete.png" style ="width:30px;height:30px"></a></td>

  </tr>
<?php  }} ?>
  </tbody>
</table>
  

</body>
</html>
