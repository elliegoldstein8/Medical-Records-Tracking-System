 <?php
  $conn = new mysqli('localhost','root','','tracking');
  
  if(ISSET($_POST['sessionme'])){
	  

	  $name = mysqli_real_escape_string($conn,$_POST['physicianAdd']);
	  $rooms = mysqli_real_escape_string($conn,$_POST['roomADD']);
	    //$diff = mysqli_real_escape_string($conn,$_POST['diffeciency']);
		
	$p1 = mysqli_real_escape_string($conn,$_POST['p1']);
	$p2 = mysqli_real_escape_string($conn,$_POST['p2']);
	$p3 = mysqli_real_escape_string($conn,$_POST['p3']);
	$p4 = mysqli_real_escape_string($conn,$_POST['p4']);
	$p5 = mysqli_real_escape_string($conn,$_POST['p5']);
	
	date_default_timezone_set('Asia/Manila');
	
	$date = date('Y-m-d');
	$patient = mysqli_real_escape_string($conn,$_POST['patient']);
	$patientNo = mysqli_real_escape_string($conn,$_POST['patientNo']);
	$date = mysqli_real_escape_string($conn,$_POST['date']);
	
	

	  
	  $sql = $conn->query("select * from patient_details where hosp_patient_no = '$patientNo' ") or die ("could not connect to mysql");
	 $rowD = $sql->fetch_array();
	$hNo =mysqli_real_escape_string($conn,$rowD['hosp_patient_no']);


	// $sql = $conn->query("select * from deficiency where deficiency_name = '$diff' ") or die ("could not connect to mysql");
	// $rowD = $sql->fetch_array();
	
	// $idD = $rowD['deficiency_id'];
	  $sqlX = $conn->query("select * from doctor_details where doctor_name = '$name' ") or die ("could not connect to mysql");
	 $rowX= $sqlX->fetch_array();
	 $doctorID = $rowX['doctor_id'];
	 
	
	 
	 
	 
		$doctorName = mysqli_real_escape_string($conn,$rowX['doctor_name']);
	   //$difName = mysqli_real_escape_string($conn,$rowD['deficiency_name']);
	 
	 
	 if($doctorName==$name AND $hNo==$patientNo){
	  
	 $conn->query("insert into tbl_session_transaction(admitting_physician,room_id,attending_physician,hosp_patient_no,date)values('$doctorID','$rooms','$p1<br>$p2<br>$p3<br>$p4<br>$p5','$hNo','$date')");
	  echo"<script> window.location='bridge.php'</script>";
	 }elseif($doctorName==$name AND $hNo!=$patientNo){
	  
	  
	  $conn->query("insert into patient_details(hosp_patient_no,patient_name)values('$patientNo','$patient')");
	 $conn->query("insert into tbl_session_transaction(admitting_physician,room_id,attending_physician,hosp_patient_no,date)values('$doctorID','$rooms','$p1<br>$p2<br>$p3<br>$p4<br>$p5','$patientNo','$date')");
	  echo"<script> window.location='bridge.php'</script>";
	  
	  
	 }elseif($doctorName!=$name AND $hNo!=$patientNo){
	  
	  
	  $conn->query("insert into patient_details(hosp_patient_no,patient_name)values('$patientNo','$patient')");
	  $conn->query("insert into doctor_details(doctor_name)values('$name')");
			$doc=mysqli_insert_id($conn);
	 $conn->query("insert into tbl_session_transaction(admitting_physician,room_id,attending_physician,hosp_patient_no,date)values('$doc','$rooms','$p1<br>$p2<br>$p3<br>$p4<br>$p5','$patientNo','$date')");
	  echo"<script> window.location='bridge.php'</script>";
	  
	  
	 }elseif($doctorName!=$name AND $hNo==$patientNo){
	  
	
			$conn->query("insert into doctor_details(doctor_name)values('$name')");
			$doc=mysqli_insert_id($conn);
		
			
	 $conn->query("insert into tbl_session_transaction(admitting_physician,room_id,attending_physician,hosp_patient_no,date)values('$doc','$rooms','$p1<br>$p2<br>$p3<br>$p4<br>$p5','$patientNo','$date')");
	   echo"<script>window.location='bridge.php'</script>";
	

	
	 }
	  
  }
  
  ?>
