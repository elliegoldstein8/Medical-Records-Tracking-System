<?php
$db = mysqli_connect('localhost', 'root', '', 'tracking');

//para sa tracking table
$def_pat_id = '';
$admitting_physician = '';
$attending_physician = '';
$att_phy = '';
$deficiencies_id = '';
$room_id= '';
$hosp_patient_no = '';
$overall_status = '';

//for patient details

$patient_name = '';
$discharged_date = '';
$doctor_name = '';
$room_name= '';
$deficiency_name = '';
$deficiency_status= '';

$doctor_date = '';
$doctor_dateu = '';
$doc_id = '';
$defname = '';



//TRACKING
if (isset($_GET['edit'])){
	$hosp_patient_no = $_GET['edit'];
	$querytracking = mysqli_query($db, "SELECT * FROM deficiency_patient_details WHERE hosp_patient_no = '$hosp_patient_no'");
	while ($request = mysqli_fetch_array($querytracking)){
		$a1 = $request['admitting_physician'];
		$a2 = $request['attending_physician'];
		$a3 = $request['deficiencies_id'];
		$a4 = $request['room_id'];
		$a5 = $request['overall_status'];
		$a6 = $request['hosp_patient_no'];
		$a7 = $request['def_pat_id'];

//query patient_name and discharged_date
		$querypatient = mysqli_query($db, "SELECT * FROM patient_details WHERE hosp_patient_no = '$a6'");
		while ($row = mysqli_fetch_array($querypatient)){
			$patient_name = $row['patient_name'];
			$discharged_date = $row['discharged_date'];
		}
    //  $querytrack = mysqli_query($db, "SELECT * FROM deficiency_patient_details WHERE hosp_patient_no = '$hosp_patient_no'");

//query admitting doctor's name
    $querydoctor = mysqli_query($db, "SELECT doctor_name FROM doctor_details WHERE doctor_id = '$a1' ");
    $res = mysqli_fetch_assoc($querydoctor);
    $doctor_name = $res["doctor_name"];

    //query room name
    $queryroom = mysqli_query($db, "SELECT room_name FROM room WHERE room_id = '$a4'");
    $res2 = mysqli_fetch_assoc($queryroom);
    $room_name = $res2["room_name"];

    //query attending name
    $queryattend = mysqli_query($db, "SELECT physician_id FROM deficiency_patient_details WHERE attending_physician = '2'");
    $res3 = mysqli_fetch_array($queryattend);
    $attending_physician = $res3['att_physician_id'];
	

	$queryattendname = mysqli_query($db, "SELECT * FROM doctor_details WHERE doctor_id = '$attending_physician'");
	while ($res4 = mysqli_fetch_array($queryattendname)){
		$att_phy = $res4['doctor_name'];
	}

//if user clicks start

    if (isset ($_POST['start_track'])){
       $statusid_selected= mysqli_real_escape_string($db, $_POST['hidden_id']);
       $name_selected = mysqli_real_escape_string($db,$_POST['hidden_deficiency'] );
       $status_selected= mysqli_real_escape_string ($db, $_POST['hidden_status']);
       $deficienciesid_selected = mysqli_real_escape_string($db, $_POST['hidden_deficiencies_id']);
       $deficiencyid_selected = mysqli_real_escape_string($db, $_POST['hidden_deficiency_id']);

     //  $disableforeignkeychecking = ($db, "SET foreign_keT");
       
       if ($status_selected== "Finished"){
       	echo '<script language="javascript">';
        echo 'alert("You cannot start a progress if you have finished it already.")';
        echo '</script>';
       }

       else{
       	 $startquery = "UPDATE deficiency_patient_details SET overall_status = 'On Progress' WHERE hosp_patient_no = '$a6' ";
       if (mysqli_query($db, $startquery)){
       	header("Refresh:0");
       }
       }
      
       }

// if user clicks Cancel
 if (isset ($_POST['cancel_track'])){
       $statusid_selected= mysqli_real_escape_string($db, $_POST['hidden_id']);
       $name_selected = mysqli_real_escape_string($db,$_POST['hidden_deficiency'] );
       $status_selected= mysqli_real_escape_string ($db, $_POST['hidden_status']);
       $deficienciesid_selected = mysqli_real_escape_string($db, $_POST['hidden_deficiencies_id']);
       $deficiencyid_selected = mysqli_real_escape_string($db, $_POST['hidden_deficiency_id']);

     //  $disableforeignkeychecking = ($db, "SET foreign_keT");
       $startquery = "UPDATE deficiency_patient_details SET overall_status = 'Not Started' WHERE hosp_patient_no = '$a6'  ";

       if (mysqli_query($db, $startquery)){
       	header("Refresh:0");
       }
      
       }

//if user clicks finish
 if (isset ($_POST['finish_track'])){
       $statusid_selected= mysqli_real_escape_string($db, $_POST['hidden_id']);
       $name_selected = mysqli_real_escape_string($db,$_POST['hidden_deficiency'] );
       $status_selected= mysqli_real_escape_string ($db, $_POST['hidden_status']);
       $deficienciesid_selected = mysqli_real_escape_string($db, $_POST['hidden_deficiencies_id']);
       $deficiencyid_selected = mysqli_real_escape_string($db, $_POST['hidden_deficiency_id']);

     //  $disableforeignkeychecking = ($db, "SET foreign_keT");
       if ($status_selected == "On Progress"){
       $startquery = "UPDATE deficiency_patient_details SET overall_status = 'Finished' WHERE hosp_patient_no = '$a6'  ";
        if (mysqli_query($db, $startquery)){
       	header("Refresh:0");
        }
   }

       else{
       	echo '<script language="javascript">';
        echo 'alert("You cannot finish a progress if you havent started it.")';
        echo '</script>';
        }
      
       }

	}
	//query hosp_patient_no, room_id, admitting_physician
/**	$querytracking = mysqli_query($db, "SELECT * FROM deficiency_patient_details WHERE def_pat_id= '$def_pat_id'");
	while ($request = mysqli_fetch_assoc($querytracking)){
		$a1 = $request["hosp_patient_no"];
		$a2 = $request["room_id"];
		$a3 = $request["admitting_physician"];
		$a4 = $request["deficiencies_id"];
		//query patient_name and discharged_date
		$querypatient = mysqli_query($db, "SELECT * FROM patient_details WHERE hosp_patient_no = '$a1'");
		while ($row = mysqli_fetch_array($querypatient)){
			$patient_name = $row['patient_name'];
			$discharged_date = $row['discharged_date'];
		}
		//query admitting doctor's name
		$querydoctor = mysqli_query($db, "SELECT doctor_name FROM doctor_details WHERE doctor_id = '$a3' ");
		$res = mysqli_fetch_assoc($querydoctor);
		$doctor_name = $res["doctor_name"];
		//query room name
		$queryroom = mysqli_query($db, "SELECT room_name FROM room WHERE room_id = '$a2'");
		$res2 = mysqli_fetch_assoc($queryroom);
		$room_name = $res2["room_name"];
		//for deficiencies, MALI PA NI
		$querydeficiencies = mysqli_query($db, "SELECT * FROM deficiency_status WHERE deficiencies_id = '$a4' " );
	
	 if (isset ($_POST['start_track'])){
       $statusid_selected= mysqli_real_escape_string($db, $_POST['hidden_id']);
       $name_selected = mysqli_real_escape_string($db,$_POST['hidden_deficiency'] );
       $status_selected= mysqli_real_escape_string ($db, $_POST['hidden_status']);
       $deficienciesid_selected = mysqli_real_escape_string($db, $_POST['hidden_deficiencies_id']);
       $deficiencyid_selected = mysqli_real_escape_string($db, $_POST['hidden_deficiency_id']);

     //  $disableforeignkeychecking = ($db, "SET foreign_keT");
       
       if ($status_selected== "Finished"){
       	echo '<script language="javascript">';
        echo 'alert("You cannot start a progress if you have finished it already.")';
        echo '</script>';
       }

       else{
       	 $startquery = "UPDATE deficiency_status SET status = 'On Progress' WHERE deficiency_status_id = '$statusid_selected' ";
       if (mysqli_query($db, $startquery)){
       	header("Refresh:0");
       }
       }
      
       }


     if (isset ($_POST['cancel_track'])){
       $statusid_selected= mysqli_real_escape_string($db, $_POST['hidden_id']);
       $name_selected = mysqli_real_escape_string($db,$_POST['hidden_deficiency'] );
       $status_selected= mysqli_real_escape_string ($db, $_POST['hidden_status']);
       $deficienciesid_selected = mysqli_real_escape_string($db, $_POST['hidden_deficiencies_id']);
       $deficiencyid_selected = mysqli_real_escape_string($db, $_POST['hidden_deficiency_id']);

     //  $disableforeignkeychecking = ($db, "SET foreign_keT");
       $startquery = "UPDATE deficiency_status SET status = 'Not Started' WHERE deficiency_status_id = '$statusid_selected' ";

       if (mysqli_query($db, $startquery)){
       	header("Refresh:0");
       }
      
       }


    if (isset ($_POST['finish_track'])){
       $statusid_selected= mysqli_real_escape_string($db, $_POST['hidden_id']);
       $name_selected = mysqli_real_escape_string($db,$_POST['hidden_deficiency'] );
       $status_selected= mysqli_real_escape_string ($db, $_POST['hidden_status']);
       $deficienciesid_selected = mysqli_real_escape_string($db, $_POST['hidden_deficiencies_id']);
       $deficiencyid_selected = mysqli_real_escape_string($db, $_POST['hidden_deficiency_id']);

     //  $disableforeignkeychecking = ($db, "SET foreign_keT");
       if ($status_selected == "On Progress"){
       $startquery = "UPDATE deficiency_status SET status = 'Finished' WHERE deficiency_status_id = '$statusid_selected' ";
        if (mysqli_query($db, $startquery)){
       	header("Refresh:0");
        }
   }

       else{
       	echo '<script language="javascript">';
        echo 'alert("You cannot finish a progress if you havent started it.")';
        echo '</script>';
        }
      
       }
	}**/


// para sa doctor report - pangitaon ang doctor ID sa gienter na doctor
}


//For viewing deficiencies
if (isset($_GET['track'])){
    $deficiencies_id = $_GET['track'];
	$querytracking = mysqli_query($db, "SELECT * FROM deficiency_status WHERE deficiencies_id = '$deficiencies_id'");
	while ($request = mysqli_fetch_array($querytracking)){
     $deficiency_id = $request['deficiency_id'];
     $querynames = mysqli_query($db, "SELECT * FROM deficiency WHERE deficiency_id = '$deficiency_id'");
     
     while ($result = mysqli_fetch_array($querynames)){
     $defname = $result['deficiency_name'];
 }
}

}
	

//idisplay ang Doctor name sa Doctor Report
if (isset($_GET['doctor_input'])){
    $doctor_name =  $_GET['doctor_input'];
	$doctor_date = $_GET['doctor_date'];
	$doctor_dateu = $_GET['doctor_dateu'];
	if (empty($doctor_name) || empty($doctor_name)) {
		echo '<script language="javascript">';
        echo 'alert("Complete details first.")';
        echo '</script>';
	}
	else{
		$query = mysqli_query($db, "SELECT doctor_id FROM doctor_details WHERE doctor_name= '$doctor_name'");
	    $doctor_id = mysqli_fetch_assoc($query);
	    $doc_id = $doctor_id['doctor_id'];
	    //ipadayun ang reports dri
	}
}

//idisplay ang Date sa overall report
if (isset ($_GET['monthly_date'])){
	$month_date = $_GET['monthly_date'];
	$monthly_date = $_GET['doctor_date'];
	//$month_date2 = $_GET['docotr'];
	if (empty($month_date)){
	    echo '<script language="javascript">';
        echo 'alert("You didnt put anything.")';
        echo '</script>';
	}
	else{
		$query = mysqli_query($db, "SELECT * FROM patient_details WHERE discharged_date >= '$month_date' AND discharged_date < '$monthly_date'") or die(mysql_error());
		while ($row = mysqli_fetch_array($query)){
			$result = $row['hosp_patient_no'];
			$query2 = mysqli_query($db, "SELECT deficiencies_id FROM deficiency_patient_details WHERE hosp_patient_no = '$result'");
			while ($row2 = mysqli_fetch_array($query2)){
				$result2 = $row2['deficiencies_id'];
				$query3 = mysqli_query($db, "SELECT deficiency_id FROM deficiency_status WHERE deficiencies_id = '$result2'");
				while($row3 = mysqli_fetch_array($query3)){
					$result3 = $row3['deficiency_id'];
					$query4 = mysqli_query($db, "SELECT deficiency_name FROM deficiency WHERE deficiency_id = '$result3'");
				}
			}
		}
	

	}

}

//sa settings ni sya
if (isset($_POST['submitdoctor'])){
	$doctor_input = mysqli_real_escape_string($db, $_POST['doctor_input']);
	$specialization_input = mysqli_escape_string($db,$_POST['specialization_input']);
	if (empty($doctor_input) || empty($specialization_input)){
	    echo '<script language="javascript">';
        echo 'alert("Complete details first.")';
        echo '</script>';
	} 
	else{
	$q = "INSERT INTO doctor_details (doctor_name, specialization) VALUES ('$doctor_input','$specialization_input')";
	if (mysqli_query($db, $q)){
		echo "<script>alert('new record added');window.location='settings'</script>";
       
	}
	else{
		 echo "Error: " . $q . "<br>" . mysqli_error($db);
	}
	mysqli_close($db);
	}

	
}

if (isset($_POST['insertpatient'])){
	$patient_name = mysqli_real_escape_string($db, $_POST['fullName']);
	$hosp_patient_no = mysqli_real_escape_string($db, $_POST['hospNo']);
	$discharged_date = mysqli_real_escape_string($db, $_POST['dischargedDate']);
	$q = "INSERT INTO patient_details (patient_name, hosp_patient_no, discharged_date) VALUES ('$patient_name', '$hosp_patient_no', '$discharged_date')";
	if (mysqli_query($db, $q)){
		echo '<script language="javascript">';
        echo 'alert("New record created successfully")';
        echo '</script>';
	}
	else{
		 echo "Error: " . $q . "<br>" . mysqli_error($db);
	}
	mysqli_close($db);

}


?>