<?php
  $conn = new mysqli('localhost','root','','tracking');
  
if(ISSET($_POST['attend'])){
	
	
	$p1 = mysqli_real_escape_string($conn,$_POST['p1']);
	$p2 = mysqli_real_escape_string($conn,$_POST['p2']);
	$p3 = mysqli_real_escape_string($conn,$_POST['p3']);
	$p4 = mysqli_real_escape_string($conn,$_POST['p4']);
	$p5 = mysqli_real_escape_string($conn,$_POST['p5']);
	

if($p1==""){
	
	
echo "<script>alert('please input Attending Physician or Continue encode with attending physician');window.location='reg.php'</script>";	
		
}else{

		$conn->query("update deficiency_patient_details set attending_physician = '$p1<br>$p2<br>$p3<br>$p4<br>$p5' where hosp_patient_no = '' and date = '0000-00-00'  ");

echo "<script>window.location='reg.php'</script>";	
		
	
}

} 