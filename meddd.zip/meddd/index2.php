<?php include('functions.php');
 $db = mysqli_connect("localhost", "root", "", "tracking");
 $query = "SELECT * FROM deficiency_patient_details";
 $result = mysqli_query($db, $query);
 $status="";
?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Medical Records</title>
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">

   <script language="JavaScript"  src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
 <link rel= "stylesheet" href = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
 
 <script src = "https://code.jquery.com/jquery-1.12.4.js"> </script>
 <script src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
  $(function(){
   $("#tokendeficiency").autocomplete({
   source: 'searchdeficiency.php',
  });
  });
  </script>
  	  <script>
  $(function(){
   $("#admitting_input").autocomplete({
   source: 'searchdoctor.php',
  });
  });
  </script>

  	  <script>
  $(function(){
   $("#attending_input").autocomplete({
   source: 'searchdoctor.php',
  });
  });
  </script>

   <script>
  $(function(){
   $("#room_input").autocomplete({
   source: 'searchroom.php',
  });
  });
  </script>
      <link rel="stylesheet" href="css/style.css?d=<?php echo time(); ?>">

</head>

<body>
<h1 style="font-family:verdana; font-weight: bold;"> Dr. Jorge P. Royeca City Hospital</h1>
<h2 style="font-family:verdana; font-weight: bold;">Medical Records</h2>
	<div>
			<table>
				
					
						<font size="4px"> 
							<a href="index.php">ENCODE</a> 
							<a href="Reports.php">REPORT</a>
                            <a href="settings.php">SETTINGS</a>
						</font>
				</table>
				
				
				
				
				
		</div>
	
 <section class="section" style = "padding-bottom: auto;">
	<h1>Encode</h1>

	<div class="form-progress">
		<progress class="form-progress-bar" min="0" max="100" value="0" step="33" aria-labelledby="form-progress-completion"></progress>
		
		<div class="form-progress-indicator one active"></div>
		<div class="form-progress-indicator two"></div>
		<div class="form-progress-indicator three"></div>
		<div class="form-progress-indicator four"></div>
		
		<p id="form-progress-completion" class="js-form-progress-completion sr-only" aria-live="polite">0% complete</p>
	</div>
	
	
	<div class="animation-container">
		<!-- Step one -->
		<div class="form-step js-form-step" data-step="1">

			<p class="form-instructions"><strong>Click the 'Next' button to show form progression.</strong><br>
				Feel free to fill out the form with the required information. </p>

			<form action="index.php" name="form-step-1" method = "POST">
				<div class="fieldgroup">
					<input type="text" name="fullName" id="fullName" />
					<label for="fullName">Patient Fullname</label>
				</div>

				<div class="fieldgroup">
					<input type="text" name="hospNo" id="hospNo" />
					<label for="hospNo">Hospital No.</label>
				</div>

	
	<h1 style = "text-align:left; font-size:12px; padding-bottom:-900px;
	margin-bottom:-30px; font-style:sans-serif;"> Discharge Date </h1>

	<div role="group" class="date-group"
		style = "height: 1px;">
		<div class="fieldgroup month">
				<input type= "date" class = "date-group" name = "dischargedDate"
				style = "width: 350px;
						padding-top: -50px;
						">

		</div>
	</div>

	
	<div class="buttons">
							<button type="button" class="btn btn-alt js-reset">Reset</button>

						<button type="submit" name = "insertpatient" class="btn">Next</button>
				</div>
			</form>

		</div>
		
			<!-- Step two -->
			<div class="form-step js-form-step waiting hidden" data-step="2" style = "height: 800px;">

				<p class="form-instructions"><strong>Click the continue button to add Defficiencies.</strong>
						<br> You can add a multiple Attending Physician in one Admitting Physician by clicking the note below the Attending Physician Text Field </p>

				<form action="" name="form-step-2" method = "POST">
						<div class="fieldgroup">
								<input type="text" name="token" id="admitting_input" />
								<label for="token">Admitting Physician</label>
						</div>

						<div class="fieldgroup">
								<input type="text" name="token" id="room_input"/>
								<label for="token">Input Room</label>
						</div>

						<div class="fieldgroup">
								<input type="text" name="token" id="attending_input" />
								<label for="token">Attending Physician</label>
						
						


				<div class="two" style = "height: 20px; font-size:10px; font-color: #fd0012">
						<button1 onclick="nameFunction()" style = "cursor:pointer;">Click me to add another Attending Physician</button>
						</div>
						<span id="myForm" style="padding-bottom:10px;"></span>
			</div>			
						<div class="buttons">
								<button type="button" class="btn btn-alt js-reset">Back</button>

								<button type="submit" class="btn">Continue</button>
						</div>
				</form>

		</div>		
					<!-- Step three -->
			<div class="form-step js-form-step waiting hidden" data-step="3" style = "height: 500px;">

				<p class="form-instructions"><strong>Click the continue button to show form progression.</strong>
						<br> Please Enter Defficiencies</p>

				<form action="" name="form-step-3">
					<div class="fieldgroup">
								<input type="text" name="token" id="tokendeficiency" />
								<label for="token">Enter Deficiency</label>
					
						
							<div class="two" style = "height: 20px; font-size:10px; font-color: #fd0012">
						<button1 onclick="nameFunction2()">Click me to add another Attending Physician</button>
						</div>
						<span id="myForm2" style="padding-bottom:10px;"></span>
						

			</div>			
						<div class="buttons">
								<button type="button" class="btn btn-alt js-reset">Back</button>

								<button type="submit" class="btn">Continue</button>
						</div>
				</form>

		</div>
		<!-- Step four -->
			<div class="form-step js-form-step waiting hidden" data-step="4">

				<p class="form-instructions"><strong></strong>
						<br> Click Add to add another Physicians and Defficiencies, Click Submit to end transaction and save all datas</p>

				<form action="" name="form-step-4">
						

						<div class="buttons">
								<button type="button" class="btn btn-alt js-reset"><a href="indexnext.php">Add</a></button>
						</div>
						<div class="buttons">
								<button type="submit" class ="btn" style = "padding-top: 10px; margin-top: 10px;">Submit</button>
						</div>
				</form>

		</div>
	</div>
</section>

  

    <script  src="js/index.js"></script>




</body>

</html>
