<?php
//Database Configuration

$mysqli = mysqli_connect("localhost", "root", "","tracking") or die ("Database Error");

$getData = $_GET['term'];
$query = $mysqli -> query ("SELECT deficiency_name FROM deficiency WHERE deficiency_name LIKE '%".$getData."%'");
while ($row = $query -> fetch_assoc()){
$data[] = $row['deficiency_name'];
}
echo json_encode($data);

?>