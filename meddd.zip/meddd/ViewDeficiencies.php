<?php include('functions.php');
 $db = mysqli_connect("localhost", "root", "", "tracking");
 $query = "SELECT * FROM patient_details";
 $result = mysqli_query($db, $query);
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Dr. Jorge P. Royeca Hospital</title>
  <script>
function goBack() {
  window.history.back();
}
</script>
 <link rel="stylesheet" href="css/styletrack.css?d=<?php echo time(); ?>">
</head>
<body>

<h1 style="font-family:verdana; font-size: 25px;
    margin-left: 10px;"><center>Deficiencies</center></h1>
					<center>
          <table style = "margin-left: 20px;" class="flat-table" id = "table" name = "table" border = "1">

    <tr>
      <th>Deficiency ID</th>
      <th>Deficiency Name</th>
      <th style="display:none;">Deficiencies ID</th>
      <th style="display:none;">Deficiency number</th>
     
    </tr>

    <?php
 
    ?>
    <tr>
      <td>1</td>
      <td>No Nurse's Notes</td>
	  
    </tr>

 <?php

?>
    <tr>
      <td>2</td>
      <td>No IV Fluid Sheets</td>
    </tr>

    <tr>
      <td>3</td>
      <td>No Admitting Doctor's Signature</td>
    </tr>

 
	</table>
</center>
  <input type = "hidden" name= "hidden_id" id = "hidden_id">
    <input type = "hidden" name = "hidden_deficiency" id = "hidden_deficiency" >
    <input type = "hidden" name= "hidden_status" id = "hidden_status">
    <input type = "hidden" name= "hidden_deficiencies_id" id = "hidden_deficiencies_id">
    <input type = "hidden" name= "hidden_deficiency_id" id = "hidden_deficiency_id">
    
   </form>

</center>

	
 <button onclick = "goBack()" style = "margin-left: 500px;
margin-top: 50px;";> Back </button>



</body>
</html>