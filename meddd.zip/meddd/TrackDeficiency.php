<?php 	
include('session.php');
	?>
<?php
 $conn = mysqli_connect("localhost", "root", "", "tracking");
 if(ISSET($_GET['edit'])){
	 $id =$_GET['edit'];
	 $sql=$conn->query("select * from  patient_details");
	 $row1=$sql->fetch_array();
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Dr. Jorge P. Royeca Hospital</title>
 <style>
  tr{cursor: pointer;transition: all .25s ease-in-out}
  .selected{background-color: #FF8C00;font-weight:bold; color:#ffff;}
  </style>
 <link rel="stylesheet" href="css/styletrack.css?d=<?php echo time(); ?>">
</head>
<body>

<h1 style="font-family:verdana; font-size: 25px;
    margin-left: 10px;"><center>Deficiency Tracker</center></h1>
					<h2 style="font-family:verdana; font-size: 20px;
    margin-left: 10px;"><center><?php  echo $row1['patient_name'] ?></center></h2>
          <h2 style="font-family:verdana; font-size: 20px;
    margin-left: 10px;"><center>Discharged date: <?php  echo date('M,d Y',strtotime($row1['discharged_date'])); ?></center></h2>
					<center>
          <table style = "margin-left: 20px;" class="flat-table" id = "table" name = "table" border = "1">

    <tr>
      <th style="display:none;">Deficiency I	D</th>
      <th>Admitting Doctor</th>
      <th>Attending Doctor</th>
      <th>Room</th>
      <th>Deficiencies</th>
      <th>Status</th>
      <th style="display:none;">Deficiencies ID</th>
      <th style="display:none;">Deficiency number</th>
     
    </tr>
    <?php


$id = $_GET['edit'];

$sql=$conn->query("select * from  patient_details  inner join deficiency_patient_details on patient_details.hosp_patient_no = deficiency_patient_details.hosp_patient_no inner join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id inner join room on deficiency_patient_details.room_id = room.room_id inner join deficiency on deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where patient_details.hosp_patient_no = '$id'");
while($row=$sql->fetch_array()){


    ?>
    <tr>
      <td><?php  echo $row['doctor_name']; ?></td>
      <td><?php  if($row['attending_physician']==""){ echo "NONE";}else{ echo $row['attending_physician'];} ?></td>
      <td><?php  echo $row['room_name']; ?></td>
      <td><?php echo $row['deficiency_name']; ?></td>
      <td><?php  echo $row['overall_status']; ?></td>
   
 
  <?php
  
}

}

?>
   </tr>

	</table>
	   <?php
   if($row1=="false"){
	
	echo "NO RESULT FOUND";
}
?>
</center>

<p>
<form method="POST">
    <center>           
            <button style = "margin-left: 20px;" type="submit" name="start_track"> Start </button>
            <button style = "margin-left: 20px;" type = "submit" name = "cancel_track"> Reset </button>
            <button style = "margin-left: 20px;" type = "submit" name = "finish_track"> Finish</button>
            </center>
          </p>
  <input  type = "hidden" name= "hidden_id" id = "hidden_id">
    <input  type = "hidden" name = "hidden_deficiency" id = "hidden_deficiency" >
    <input type = "hidden" name= "hidden_status" id ="hidden_deficiency_id" >
    <input type = "hidden" name= "hidden_deficiencies_id" id = "hidden_deficiencies_id">
    <input type = "hidden" name= "hidden_deficiency_id" id = "hidden_status">
    
   </form>


  <script>
  function selectedRow(){
  var index,
  table = document.getElementById("table");
  
  for (var i = 1; i<table.rows.length;i++){
    table.rows[i].onclick = function()
    {
      if(typeof index!=="undefined")
      {
        table.rows[index].classList.toggle("selected");
      }

      index = this.rowIndex;
      this.classList.toggle("selected");
      console.log(typeof index);
      index = this.rowIndex;
      document.getElementById("hidden_id").value = this.cells[0].innerHTML;
      document.getElementById("hidden_deficiency").value =  this.cells[1].innerHTML;
      document.getElementById("hidden_status").value = this.cells[2].innerHTML;
      document.getElementById("hidden_deficiencies_id").value = this.cells[3].innerHTML;
      document.getElementById("hidden_deficiency_id").value = this.cells[4].innerHTML;
     
    };
  }
  }
  selectedRow();
  </script>
</center>

	
<a href="track.php"> <button style = "margin-left: 500px;
margin-top: 50px;";> Back </button></a>



</body>
</html>