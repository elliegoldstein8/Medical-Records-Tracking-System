<?php

$conn = new mysqli('localhost','root','','tracking');
$conn->query("delete from tbl_session_transaction");
echo "<script>alert('Data Successfully Added');window.location='reg.php'</script>";	

?>