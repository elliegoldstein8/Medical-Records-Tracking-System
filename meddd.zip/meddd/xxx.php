<?php
  $conn = mysqli_connect("localhost", "root", "", "tracking");
?>


<?php

$sql = $conn->query("select * from deficiency_patient_details where def_pat_id = '22'");
$row= $sql->fetch_array();



echo $row['attending_physician'];

?>