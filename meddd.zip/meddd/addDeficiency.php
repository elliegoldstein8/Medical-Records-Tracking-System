 <?php
  $conn = new mysqli('localhost','root','','tracking');
  
  if(ISSET($_POST['session'])){
	  
	  
	
	  $def = mysqli_real_escape_string($conn,$_POST['diffeciency']);
	  
	  $sql=$conn->query("select * from deficiency where deficiency_name = '$def'");
	  $row=$sql->fetch_array();
	 
	  $def2 = mysqli_real_escape_string($conn,$row['deficiency_name']);
	  $idDef = mysqli_real_escape_string($conn,$row['deficiency_id']);
	   $admit = mysqli_real_escape_string($conn,$_POST['admitting']);
	    $attend = mysqli_real_escape_string($conn,$_POST['attending']);
		 $roomID = mysqli_real_escape_string($conn,$_POST['room_id']);
		 $date = mysqli_real_escape_string($conn,$_POST['date']);
		 $patientNo = mysqli_real_escape_string($conn,$_POST['patientNo']);
		 $trick = mysqli_real_escape_string($conn,$_POST['idTrick']);
	  
	  
	  if($row>0){
		  
		    $conn->query("insert into deficiency_patient_details(admitting_physician,attending_physician,deficiencies_id,room_id,hosp_patient_no,date,id_trick)values('$admit','$attend','$idDef','$roomID','$patientNo','$date','$trick')");
		  echo"<script>window.location='reg.php#deficiency'</script>";
		  
		  
	  }else{
	  
	  $conn->query("insert into deficiency(deficiency_name)values('$def')");
	  $dhatz = mysqli_insert_id($conn);
	   $conn->query("insert into deficiency_patient_details(admitting_physician,attending_physician,deficiencies_id,room_id,hosp_patient_no,date,id_trick)values('$admit','$attend','$dhatz','$roomID','$patientNo','$date','$trick')");
		  echo"<script>window.location='reg.php#deficiency'</script>";
		
		
  }
	  
  }
  
  ?>
