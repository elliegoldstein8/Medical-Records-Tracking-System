<?php

 $conn = mysqli_connect("localhost", "root", "", "tracking");
?>
<?php
if(ISSET($_GET['ids'])){
	$ids = $_GET['ids'];
	
	$conn->query("delete from deficiency_patient_details where def_pat_id = '$ids'");
	
	
	echo "<script>window.location='reg'</script>";
	
	
	
}
?>