<?php 
 $conn= mysqli_connect("localhost", "root", "", "tracking");

?>
<?php
session_start();

if(!ISSET($_SESSION['id'])){
	
	echo"<script>window.location='index'</script>";
	
}


?>