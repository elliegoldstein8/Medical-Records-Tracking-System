<?php

 $conn = mysqli_connect("localhost", "root", "", "tracking");
?>
<?php
if(ISSET($_GET['ids'])){
	$ids = $_GET['ids'];
	
	$conn->query("update deficiency_patient_details set attending_physician = '' where def_pat_id = '$ids'");
	
	
	echo "<script>window.location='reg'</script>";
	
	
	
}
?>