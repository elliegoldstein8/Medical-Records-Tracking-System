<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Medical Records</title>
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
  
  
      <link rel="stylesheet" href="css/style2.css">

  
</head>

<body>
<h1> Dr. Jorge P. Royeca Hospital - Medical Records</h1>
	<div>
			<table>
				
					
						<font size="4px"> 
							<a href="index.php">ENCODE</a> 
							<a href="track.php">TRACK</a>  
							<a href="Reports.php">REPORT</a>
                            <a href="settings.php">SETTINGS</a>
						</font>
				</table>
		</div>
	
  <section class="section" style = "padding-bottom: auto;">
	<h1>Encode</h1>

	<div class="form-progress"
	style = "left:60px;">
		<progress class="form-progress-bar" min="0" max="100" value="0" step="33" aria-labelledby="form-progress-completion"></progress>
		
		<div class="form-progress-indicator one active"></div>
		<div class="form-progress-indicator two"></div>
		<div class="form-progress-indicator three"></div>
		
		<p id="form-progress-completion" class="js-form-progress-completion sr-only" aria-live="polite">0% complete</p>
	</div>
	
	
	<div class="animation-container">
		<!-- Step one -->
		<div class="form-step js-form-step" data-step="1">

			<p class="form-instructions"><strong>Click the 'Next' button to show form progression.</strong><br>
				Feel free to fill out the form with the required information. </p>

			
			<form action="" name="form-step-2" style="height:500px;">
						<div class="fieldgroup">
								<input type="text" name="token" id="token" />
								<label for="token">Admitting Physician</label>
						</div>
						
						<div class="fieldgroup">
								<input type="text" name="token"/>
								<label for="token">Input Room</label>
						</div>

						<div class="fieldgroup">
								<input type="text" name="token" id="token" />
								<label for="token">Attending Physician</label>

				
						
	
				<div class="two" style = "height: 20px; font-size:10px; font-color: #fd0012">
						<button1 onclick="nameFunction()">Click me to add another Attending Physician</button>
						</div>
						<span id="myForm" style="padding-bottom:10px;"></span>
			</div>			
				

	
	<div class="buttons">
							<button type="button" class="btn btn-alt js-reset">Reset</button>

						<button type="submit" class="btn">Next</button>
				</div>
			</form>

		</div>
		
			<!-- Step two -->
			<div class="form-step js-form-step waiting hidden" data-step="2" style = "height: 800px;">

			
				<p class="form-instructions"><strong>Click the continue button to show form progression.</strong>
						<br> Please Enter Defficiencies</p>

				<form action="" name="form-step-3">
					<div class="fieldgroup">
								<input type="text" name="token" id="token" />
								<label for="token">Enter Deficiency</label>
					
						
							<div class="two" style = "height: 20px; font-size:10px; font-color: #fd0012">
						<button1 onclick="nameFunction2()">Click me to add another Attending Physician</button>
						</div>
						<span id="myForm2" style="padding-bottom:10px;"></span>
						

			</div>			
						<div class="buttons">
								<button type="button" class="btn btn-alt js-reset">Back</button>

								<button type="submit" class="btn">Continue</button>
						</div>
				</form>

		</div>		
					<!-- Step three -->
			<div class="form-step js-form-step waiting hidden" data-step="3">
<p class="form-instructions"><strong></strong>
						<br> Click Add to add another Physicians and Defficiencies, Click Submit to end transaction and save all datas</p>

				<form action="" name="form-step-4">
						

						<div class="buttons">
								<button type="button" class="btn btn-alt" style = "margin-left:50px;"><a href="indexnext.html">Add</a></button>
						</div>
						<div class="buttons">
								<button type="submit" class ="btn" style = "margin-left:50px; padding-top: 10px; margin-top: 10px;"><a href="index.php">Submit</a></button>
						</div>
								</form>

		</div>
				</form>

		</div>
	</div>
</section>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>

  

    <script  src="js/index.js"></script>




</body>

</html>
