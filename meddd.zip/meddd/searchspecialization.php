<?php
//Database Configuration

$mysqli = mysqli_connect("localhost", "root", "","tracking") or die ("Database Error");

$getData = $_GET['term'];
$query = $mysqli -> query ("SELECT DISTINCT specialization FROM doctor_details WHERE specialization LIKE '%".$getData."%'");
while ($row = $query -> fetch_assoc()){
$data[] = $row['specialization'];
}
echo json_encode($data);

?>