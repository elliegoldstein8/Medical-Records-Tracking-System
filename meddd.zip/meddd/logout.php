<?php
 $conn = mysqli_connect("localhost", "root", "", "tracking");
session_start();

session_destroy();

echo "<script>window.location='index'</script>";

?>