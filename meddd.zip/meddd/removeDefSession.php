  <?php  
 
   $conn = new mysqli('localhost','root','','tracking');


if(ISSET($_GET['idx'])){
	$idx = $_GET['idx'];
   $conn->query("delete from deficiency_patient_details where  def_pat_id = '$idx' ");
echo "<script>window.location='reg.php#deficiency'</script>";	
}
   ?>