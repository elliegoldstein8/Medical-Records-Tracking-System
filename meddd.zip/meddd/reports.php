<?php 	
include('session.php');
	?>
<?php include('functions.php');
	
 $db = mysqli_connect("localhost", "root", "", "tracking");
 $query = "SELECT * FROM deficiency_patient_details";
 $result = mysqli_query($db, $query);
 $status="";
?>

<html>
<head>
<meta charset="UTF-8">
  <title>Medical Records</title>
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
 
   <script language="JavaScript"  src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
 <link rel= "stylesheet" href = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
 
 <script src = "https://code.jquery.com/jquery-1.12.4.js"> </script>
 <script src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


    <script  src="js/index.js"></script>
      <link rel="stylesheet" href="css/style.css">
	  <script>
  $(function(){
   $("#doctor_input").autocomplete({
   source: 'searchdoctor.php',
  });
  });
  </script>
   <meta name="viewport" content="width=device-width, initial-scale=1">


</head>
<body>
<h1 style="font-family:verdana; font-weight: bold;"> Dr. Jorge P. Royeca City Hospital</h1>
<h2 style="font-family:verdana; font-weight: bold;">Medical Records</h2>
<div>
			<table>
				
					<?php $dhatz = '2787zzzjhsjhxjhcjhuyueryeyruyu';?>
						<font size="4px"> 
							<a href="reg">ENCODE</a>
									<a href="track">TRACK</a>  
							<a href="Reports">REPORT</a>
                            <a href="settings">SETTINGS</a>
							  <a href="patient" style ="background-color:green;color:#fff;padding:2px 10px 2px">PATIENT LIST</a>
								<a href="logout.php">LOGOUT</a>
						</font>
				</table>
		</div>
	
<script type="text/javascript">
$(document).ready(function(){    
    //Check if the current URL contains '#'
    if(document.URL.indexOf("#")==-1){
        // Set the URL to whatever it was plus "#".
        url = document.URL+"#";
        location = "#";

        //Reload the page
        location.reload(true);
    }
});
</script>
<div style ="float:left;margin-left:200px;margin-top:-60px;">
  <section class="section">
	<h1>Generate Reports</h1>
	<h2 style = "padding-top: 25px;">Search by Doctor</h2>
	<form method="GET" action="DoctorReport.php?<?php echo $_GET['doctor_input'] + $_GET['doctor_date'] + $_GET['doctor_dateu']; ?>" >
					<input id="doctor_input" name = "doctor_input" oninvalid="this.setCustomValidity('Please Enter Doctor`s Name')" oninput="setCustomValidity('')" style="font-size: 18px; height: 40px; width: 350px;" type="text" placeholder="Enter Doctor Name"  required/>

 </p>
 <h1 style = "text-align:left; font-size:12px; padding-bottom:-900px;
	margin-bottom:-30px; font-style:sans-serif;"> From: </h1>

  <p>
 <p>
			<input type= "date" class = "date-group" name = "doctor_date"
				style = "width: 350px;
						padding-top: 30px; font-size: 18px;" oninvalid="this.setCustomValidity('Please Input Start Date')" oninput="setCustomValidity('')"  required>
 </p>
 <h1 style = "text-align:left; font-size:12px; padding-bottom:-900px;
	margin-bottom:-30px; font-style:sans-serif;"> To: </h1>

  <p>
			<input type= "date" class = "date-group" name = "doctor_dateu" oninvalid="this.setCustomValidity('Please Input End Date')" oninput="setCustomValidity('')" 
				style = "width: 350px;
						padding-top: 30px; font-size: 18px;" required>
 </p>

 <div class="buttons">

						<button type="submit" style = "margin-left:200px;background-color:green;cursor:pointer" class="btn">Continue</button>
				</div>
					</form>

  </div>
  
  <div style ="float:right;margin-right:160px;margin-top:-60px;">
    <section class="section">
	<h1 style = "padding-top: 0px;">Overall Report</h1>
	<br>
	<br>
	
	 <h1 style = "text-align:left; font-size:12px; padding-bottom:-900px;
	margin-bottom:-30px; font-style:sans-serif;"> From: </h1>

 <p>
 <form method="GET" action="Monthly.php?<?php echo $_GET['monthly_date'] + $_GET['doctor_date'] ; ?>" >
<input type= "date" class = "date-group" name = "monthly_date" style = "width: 350px;padding-top: -850px; font-size: 18px;" oninvalid="this.setCustomValidity('Please Input Start Date')" oninput="setCustomValidity('')" required> </p>
  <h1 style = "text-align:left; font-size:12px; padding-bottom:-900px;
	margin-bottom:-30px; font-style:sans-serif;" > To: </h1>
  <p>
<input type= "date" class = "date-group" name = "doctor_date" oninvalid="this.setCustomValidity('Please Input End Date')" oninput="setCustomValidity('')" style = "width: 350px;padding-top: 30px; font-size: 18px;" required>
 </p>
 <br>
	<br>
	<br><br>
	<br>
 <div class="buttons">
<button type="submit" style = "margin-left: 200px;background-color:green;cursor:pointer;" class="btn">Continue</button>
</div>
</form>
</section>



</body>
</html>