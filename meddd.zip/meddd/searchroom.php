<?php
//Database Configuration

$mysqli = mysqli_connect("localhost", "root", "","tracking") or die ("Database Error");

$getData = $_GET['term'];
$query = $mysqli -> query ("SELECT room_name FROM room WHERE room_name LIKE '%".$getData."%'");
while ($row = $query -> fetch_assoc()){
$data[] = $row['room_name'];
}
echo json_encode($data);

?>