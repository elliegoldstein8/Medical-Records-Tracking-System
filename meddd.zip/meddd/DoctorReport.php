<?php include('functions.php');
 $db = mysqli_connect("localhost", "root", "", "tracking");
 $query = "SELECT * FROM patient_details";
 $result = mysqli_query($db, $query);
?>

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Dr. Jorge P. Royeca Hospital</title>
  
 <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
  
     
 <link rel="stylesheet" href="css/styledoctorreport.css?d=<?php echo time(); ?>">

</head>
<body style ="background-color:#121212;">

<h1 style="font-size: 25px; font-family:verdana;color:white;"><center>Audit Deficiency Report</center></h1>
					<h2 style="font-family:verdana;color:white;"><center><?php  echo $doctor_name; ?></center></h2>
					<h3 style="font-family:verdana;color:white;"><center><?php  echo date ('M d, Y-', strtotime($doctor_date)); echo date ('M d, Y', strtotime($doctor_dateu)); ?></center></h3>
					<center>
			<?php
			  $conn = mysqli_connect("localhost", "root", "", "tracking");

					$datefrom=date('Y-m-d', strtotime($doctor_date));
					
					$dateto =date('Y-m-d', strtotime($doctor_dateu));
					
					
					$sql = $conn->query("select * from doctor_details where doctor_name = '$doctor_name' ");
					$row =$sql->fetch_array();
					
					$doctorID = $row['doctor_id'];
	
					?>				
	<style>
tr{
	height:10px;
}
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
  background-color:white;
}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: green;
  color: white;
}
</style>
</style>	
					
          <table style = "margin-left: 20px;" id="customers">
  <tbody style="height:10px;">
    <tr>
      <th>Deficiency</th>
      <th>Total</th>
	  <th>Deficiency</th>
      <th>Total</th>
     
    </tr>
	
	   <tr>
      <td>Clinical Cover Sheet-No AP Signature</td>
    <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '5'  and date between '$datefrom' and '$dateto'");
	  $rowMed1=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed1['medical']; ?></td>
    
	  <td>Clinical History & Physical Examination - No AP Signature</td>
          <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '7'  and date between '$datefrom' and '$dateto'");
	  $rowMed3=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed3['medical']; ?></td>
    
    </tr>

    <tr>
      <td>Clinical Cover Sheet-No Diagnosis</td>
        <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '6'  and date between '$datefrom' and '$dateto'");
	  $rowMed2=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed2['medical']; ?></td>
	       <td>Clinical History & Physical Examination - No Admitting Diagnosis</td>
       <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '8'  and date between '$datefrom' and '$dateto'");
	  $rowMed4=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed4['medical']; ?></td>
    
    </tr>
	

	<tr>
      <td>No Vital Signs</td>
         <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '3'  and date between '$datefrom' and '$dateto'");
	  $rowMed5=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed5['medical']; ?></td>
 
      <td>No Vital Signs Graphic Chart</td>
       <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '4'  and date between '$datefrom' and '$dateto'");
	  $rowMed6=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed6['medical']; ?></td>
     <!_------------------------------------------------------------->
    </tr>
	<tr>
      <td>Doctor's Order - No AP Signature</td>
         <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '9'  and date between '$datefrom' and '$dateto'");
	  $rowMed7=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed7['medical']; ?></td>
	  
	   <td>Doctor's Order - Incomplete Discharge Plan</td>
          <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '11'  and date between '$datefrom' and '$dateto'");
	  $rowMed9=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed9['medical']; ?></td>
     
     
    </tr>
	<tr>
      <td>Doctor's Order - No CounterSign by Nurse</td>
        <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '10'  and date between '$datefrom' and '$dateto'");
	  $rowMed8=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed8['medical']; ?></td>
     
	 
	 <td>Nurses Notes - No Nurse Signature</td>
         <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '2'  and date between '$datefrom' and '$dateto'");
	  $rowMed11=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed11['medical']; ?></td>
    
    </tr>
	
	 <tr>
      <td>No Mediation Record sheet - No Specimen Signs</td>
         <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '12'  and date between '$datefrom' and '$dateto'");
	  $rowMed10=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed10['medical']; ?></td>
    
	
	      <td>No IV fluid Sheet</td>
        <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '1'  and date between '$datefrom' and '$dateto'");
	  $rowMed12=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed12['medical']; ?></td>
 

    
    </tr>
	
	 <tr>
      <td>Incomplete Discharge Summary - No course in the ward</td>
         <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '13'  and date between '$datefrom' and '$dateto'");
	  $rowMed13=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed13['medical']; ?></td>
	  
	    <td>Incomplete Discharge Summary - No AP Signature</td>
         <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '15'  and date between '$datefrom' and '$dateto'");
	  $rowMed15=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed15['medical']; ?></td>
    
    </tr>
	
	
	

	
	 <tr>
      <td>Incomplete Discharge Summary - No final Diagnosis</td>
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '14'  and date between '$datefrom' and '$dateto'");
	  $rowMed14=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed14['medical']; ?></td>
    
	 <td style = "background-color:red;text-align:center;font-size:20px;color:#fff"><?php  echo $doctor_name; ?></td>
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '14'  and date between '$datefrom' and '$dateto'");
	  $rowMed14=$sqlMedical->fetch_array();
	  ?>
      <td></td>
    </tr>
	

   

  

 <?php $sqlDefx= $conn->query("select * from deficiency where deficiency_id > 15");
		$rowDefx=$sqlDefx->fetch_array();
	
 ?>
   <tr style="background-color:gray;">
      <th style="background-color:gray;">New Deficiency</th>
      <th style="background-color:gray;"></th>
	  <th style="background-color:gray;"></th>
      <th style="background-color:gray;"></th>
	  
     
    </tr>
	
	<?php $sqlDef= $conn->query("select * from deficiency where deficiency_id > 15");
		while($rowDef=$sqlDef->fetch_array()){
			$deficiency = $rowDef['deficiency_id'];
 ?>

	   <tr>
      <td><?php echo $rowDef['deficiency_name'];?></td>
    <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details where admitting_physician = '$doctorID' and deficiencies_id = '$deficiency'  and date between '$datefrom' and '$dateto'");
	  $rowMed1=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed1['medical']; ?></td>
	  <td></td> 
      <td></td>
    </tr>
		<?php } ?>
  </tbody>
	</table>
</center>

	<div style ="display:block">			
<button onclick="javascript:history.go(-1)" style = "margin-left: 690px;  text-align: center;
margin-top: 50px;background-color:green;font-size:20px;cursor:pointer"> BACK </button>
<button style ="background-color:#12AE5B;cursor:pointer"  onclick="tablesToExcel(['customers'], ['Deficiencies_report'], '<?php  echo $doctor_name; ?>-<?php  echo date ('M d, Y-', strtotime($doctor_date)); echo date ('M d, Y', strtotime($doctor_dateu)); ?>.xls', 'Excel')">Export to Excel</button>


</div>

<script>

var tablesToExcel = (function() {
    var uri = 'data:application/vnd.ms-excel;base64,'
    , tmplWorkbookXML = '<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">'
      + '<DocumentProperties xmlns="urn:schemas-microsoft-com:office:office"><Author>Axel Richter</Author><Created>{created}</Created></DocumentProperties>'
      + '<Styles>'
      + '<Style ss:ID="Currency"><NumberFormat ss:Format="Currency"></NumberFormat></Style>'
      + '<Style ss:ID="Date"><NumberFormat ss:Format="Medium Date"></NumberFormat></Style>'
      + '</Styles>' 
      + '{worksheets}</Workbook>'
    , tmplWorksheetXML = '<Worksheet ss:Name="{nameWS}"><Table>{rows}</Table></Worksheet>'
    , tmplCellXML = '<Cell{attributeStyleID}{attributeFormula}><Data ss:Type="{nameType}">{data}</Data></Cell>'
    , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
    , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
    return function(tables, wsnames, wbname, appname) {
      var ctx = "";
      var workbookXML = "";
      var worksheetsXML = "";
      var rowsXML = "";
	  

      for (var i = 0; i < tables.length; i++) {
        if (!tables[i].nodeType) tables[i] = document.getElementById(tables[i]);
        for (var j = 0; j < tables[i].rows.length; j++) {
          rowsXML += '<Row>'
          for (var k = 0; k < tables[i].rows[j].cells.length; k++) {
            var dataType = tables[i].rows[j].cells[k].getAttribute("data-type");
            var dataStyle = tables[i].rows[j].cells[k].getAttribute("data-style");
            var dataValue = tables[i].rows[j].cells[k].getAttribute("data-value");
            dataValue = (dataValue)?dataValue:tables[i].rows[j].cells[k].innerHTML;
            var dataFormula = tables[i].rows[j].cells[k].getAttribute("data-formula");
            dataFormula = (dataFormula)?dataFormula:(appname=='Calc' && dataType=='DateTime')?dataValue:null;
            ctx = {  attributeStyleID: (dataStyle=='Currency' || dataStyle=='Date')?' ss:StyleID="'+dataStyle+'"':''
                   , nameType: (dataType=='Number' || dataType=='DateTime' || dataType=='Boolean' || dataType=='Error')?dataType:'String'
                   , data: (dataFormula)?'':dataValue
                   , attributeFormula: (dataFormula)?' ss:Formula="'+dataFormula+'"':''
				   
                  };
            rowsXML += format(tmplCellXML, ctx);
          }
          rowsXML += '</Row>'
        }
        ctx = {rows: rowsXML, nameWS: wsnames[i] || 'Sheet' + i};
        worksheetsXML += format(tmplWorksheetXML, ctx);
        rowsXML = "";
      }

      ctx = {created: (new Date()).getTime(), worksheets: worksheetsXML};
      workbookXML = format(tmplWorkbookXML, ctx);



      var link = document.createElement("A");
      link.href = uri + base64(workbookXML);
      link.download = wbname || 'Workbook.xls';
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  })();


  
  
  
</script>

<script>
private void ExporttoExcel(DataTable table)
    {
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.ClearContent();
        HttpContext.Current.Response.ClearHeaders();
        HttpContext.Current.Response.Buffer = true;
        HttpContext.Current.Response.ContentType = "application/ms-excel";
        HttpContext.Current.Response.Write(@");
        HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=Reports.xls");

        HttpContext.Current.Response.Charset = "utf-8";
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
        //sets font
        HttpContext.Current.Response.Write("<font style="font-size:10.0pt; font-family:Calibri;">");
        HttpContext.Current.Response.Write("<br><br><br>");
        //sets the table border, cell spacing, border color, font of the text, background, foreground, font height
        HttpContext.Current.Response.Write("<table border="1" bgcolor="#ffffff" hold=" />          " bordercolor="#000000" cellspacing="0" cellpadding="0" style="font-size:10.0pt; font-family:Calibri; background:white;"> <tr>");
        ////am getting my grid's column headers
        //int columnscount = g .Columns.Count;

        //for (int j = 0; j < columnscount; j++)
        //{      //write in new column
        //    HttpContext.Current.Response.Write("<td>");
        //    //Get column headers  and make it as bold in excel columns
        //    HttpContext.Current.Response.Write("");
        //    HttpContext.Current.Response.Write(GridView_Result.Columns[j].HeaderText.ToString());
        //    HttpContext.Current.Response.Write("");
        //    HttpContext.Current.Response.Write("</td>");
        //}
        HttpContext.Current.Response.Write("</tr>");
        foreach (DataRow row in table.Rows)
        {//write in new row
            HttpContext.Current.Response.Write("<tr>");
            
            HttpContext.Current.Response.Write("<td>");
            HttpContext.Current.Response.Write(row[0].ToString());
            HttpContext.Current.Response.Write("</td>");
            HttpContext.Current.Response.Write("<td style="width: 100px;">");
            HttpContext.Current.Response.Write(row[1].ToString());
            HttpContext.Current.Response.Write("</td>");
            HttpContext.Current.Response.Write("<td>");
            HttpContext.Current.Response.Write(row[2].ToString());
            HttpContext.Current.Response.Write("</td>");
            HttpContext.Current.Response.Write("<td style="width: 100px;">");
            HttpContext.Current.Response.Write(row[3].ToString());
            HttpContext.Current.Response.Write("</td>");
            HttpContext.Current.Response.Write("<td>");
            HttpContext.Current.Response.Write(row[4].ToString());
            HttpContext.Current.Response.Write("</td>");
            HttpContext.Current.Response.Write("<td>");
            HttpContext.Current.Response.Write(row[5].ToString());
            HttpContext.Current.Response.Write("</td>");

            HttpContext.Current.Response.Write("</tr>");
        }
        HttpContext.Current.Response.Write("</table>");
        HttpContext.Current.Response.Write("</br></br></br></font>");
        HttpContext.Current.Response.Flush();
        HttpContext.Current.Response.End();
    }
</script>

</body>
</html>