  <?php  
  
   $conn = new mysqli('localhost','root','','tracking');
	$sqlQQx = $conn->query("select * from tbl_session_transaction");
	$rowQQx= $sqlQQx->fetch_array();
		
		if($rowQQx==null){
			 echo"<script>window.location='reg.php#admitting'</script>";
		}else{
		
			 echo"<script>window.location='reg.php#deficiency'</script>";
			
		}
?>


<label for="email">Hospital Patient No.:</label>
<input type="text" name="patientNo" id= "patients" onkeyup="this.value=this.value.replace(/[^0-9 ]/g,'')"
 class="txt" oninvalid="this.setCustomValidity('Please Input Patient number here')" oninput="setCustomValidity('')" required />
</div>


<div>
<label for="fullname">Patient Fullname:</label>
<input type="text" name="patient"  id="patient" onkeyup="this.value=this.value.replace(/[^a-zA-Z ]/g,'')"
 class="txt" oninvalid="this.setCustomValidity('Please Enter Patient Fullname')" oninput="setCustomValidity('')"  required/>
</div>
 
  

<div>

<label for="password2">Discharge Date:</label>
<input type="date" name="date" id="password2" class="txt" oninvalid="this.setCustomValidity('Select Discharge Date')" oninput="setCustomValidity('')" required/>
</div>