<?php
//Database Configuration

$mysqli = mysqli_connect("localhost", "root", "","tracking") or die ("Database Error");

$getData = $_GET['term'];
$query = $mysqli -> query ("SELECT patient_name FROM patient_details WHERE hosp_patient_no LIKE '%".$getData."%'");
while ($row = $query->fetch_assoc()){
$data[] = $row['hosp_patient_no'];
}
echo json_encode($data);

?>