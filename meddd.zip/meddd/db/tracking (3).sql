-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2019 at 08:47 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tracking`
--

-- --------------------------------------------------------

--
-- Table structure for table `attending`
--

CREATE TABLE `attending` (
  `id` int(12) NOT NULL,
  `att_physician_id` varchar(50) NOT NULL,
  `attending_physician` varchar(100) NOT NULL,
  `def_id` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dateme`
--

CREATE TABLE `dateme` (
  `id` int(12) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dateme`
--

INSERT INTO `dateme` (`id`, `date`) VALUES
(1, '2019-06-07');

-- --------------------------------------------------------

--
-- Table structure for table `deficiency`
--

CREATE TABLE `deficiency` (
  `deficiency_id` int(11) NOT NULL,
  `deficiency_name` varchar(535) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deficiency`
--

INSERT INTO `deficiency` (`deficiency_id`, `deficiency_name`) VALUES
(1, 'No IV Fluid Sheet'),
(2, 'Nurses Notes - No Nurse Signature'),
(3, 'No Vital Signs'),
(4, 'No Vital Signs Graphic Chart'),
(5, 'Clinical Coversheet - No AP Signature'),
(6, 'Clinical Coversheet - No Diagnosis'),
(7, 'Clinical History & Physical Examination-No AP Signature'),
(8, 'Clinical History & Physical Examination-No Admitting Diagnosis'),
(9, 'Doctor\'s Order-No AP Signature'),
(10, 'Doctor\'s Order-No CounterSign by Nurse'),
(11, 'Doctor\'s Order-Incomplete Discharge Plan'),
(12, 'No Mediation Record sheet-No Specimen Signs'),
(13, 'Incomplete Discharge Summary - No course in the ward'),
(14, 'Incomplete Discharge Summary - No final Diagnosis'),
(15, 'Incomplete Discharge Summary - No AP Signature');

-- --------------------------------------------------------

--
-- Table structure for table `deficiency_patient_details`
--

CREATE TABLE `deficiency_patient_details` (
  `def_pat_id` int(20) NOT NULL,
  `admitting_physician` varchar(100) NOT NULL,
  `attending_physician` varchar(100) NOT NULL,
  `deficiencies_id` varchar(200) NOT NULL,
  `room_id` varchar(50) NOT NULL,
  `hosp_patient_no` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `overall_status` varchar(255) NOT NULL,
  `id_trick` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deficiency_patient_details`
--

INSERT INTO `deficiency_patient_details` (`def_pat_id`, `admitting_physician`, `attending_physician`, `deficiencies_id`, `room_id`, `hosp_patient_no`, `date`, `overall_status`, `id_trick`) VALUES
(90, '2', 'a<br>asa<br>as<br>as<br>asasa', '4', '8', '12345', '2019-06-19', '', '66'),
(91, '2', 'a<br>asa<br>as<br>as<br>asasa', '12', '8', '12345', '2019-06-19', '', '66'),
(92, '15', 'a<br>a<br><br><br>', '5', '9', '12345', '2019-06-20', '', '68'),
(93, '1', 'Dr. Khebb<br><br><br><br>', '1', '7', '54', '2019-06-07', '', '1'),
(94, '1', 'Dr. Khebb<br><br><br><br>', '6', '7', '54', '2019-06-07', '', '1'),
(96, '2', 'sa<br><br><br><br>', '12', '9', '445', '2019-06-07', '', '2');

-- --------------------------------------------------------

--
-- Table structure for table `deficiency_patient_details2`
--



-- --------------------------------------------------------

--
-- Table structure for table `deficiency_status`
--

CREATE TABLE `deficiency_status` (
  `deficiencies_id` varchar(255) NOT NULL,
  `deficiency_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `deficiency_status_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deficiency_status`
--

INSERT INTO `deficiency_status` (`deficiencies_id`, `deficiency_id`, `status`, `deficiency_status_id`) VALUES
('1', 1, 'Not Started', 1),
('1', 2, 'Not Started', 2),
('2', 1, 'Not Started', 3);

-- --------------------------------------------------------

--
-- Table structure for table `doctor_details`
--

CREATE TABLE `doctor_details` (
  `doctor_id` int(11) NOT NULL,
  `doctor_name` varchar(255) NOT NULL,
  `specialization` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_details`
--

INSERT INTO `doctor_details` (`doctor_id`, `doctor_name`, `specialization`) VALUES
(1, 'Dr. Maria Labo', 'Psychiatrist'),
(2, 'Dr. Kil La Kil', 'Wewologist'),
(3, 'Dr. Khebb', 'Dentist'),
(4, 'Dr. Elizabeth Joy Lik', 'ENT'),
(15, 'aasasas', '');

-- --------------------------------------------------------

--
-- Table structure for table `patient_details`
--

CREATE TABLE `patient_details` (
  `id` int(20) NOT NULL,
  `hosp_patient_no` varchar(20) NOT NULL,
  `patient_name` varchar(100) NOT NULL,
  `discharged_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_details`
--

INSERT INTO `patient_details` (`id`, `hosp_patient_no`, `patient_name`, `discharged_date`) VALUES
(1, '12345', 'amir edsil', '0000-00-00'),
(2, '1233', 'amir edsil', '0000-00-00'),
(3, '1234', 'amir edsil', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `patient_details2`
--

--
-- Dumping data for table `patient_details2`
--


-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` int(11) NOT NULL,
  `room_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `room_name`) VALUES
(1, 'Military Ward'),
(2, 'Payward'),
(3, 'Pediatric'),
(4, 'Obstetric'),
(5, 'OB/Gyne'),
(6, 'Surgical'),
(7, 'ICU'),
(8, 'NICU-Well Baby'),
(9, 'NICU-Non Pathologic'),
(10, 'NICU-Pathologic'),
(11, 'Septic Neonate'),
(12, 'BBS-Non Pathologic'),
(13, 'BBS-Well Baby'),
(14, 'Medical');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_administrator`
--

CREATE TABLE `tbl_administrator` (
  `id` int(12) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_administrator`
--

INSERT INTO `tbl_administrator` (`id`, `username`, `password`) VALUES
(1, 'administrator', 'administrator'),
(2, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sessiondeficiency`
--

CREATE TABLE `tbl_sessiondeficiency` (
  `id` int(12) NOT NULL,
  `deficiencyX` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sessiondeficiency`
--

INSERT INTO `tbl_sessiondeficiency` (`id`, `deficiencyX`) VALUES
(1, ''),
(2, 'Clinical History & Physical Examination-No AP Signature'),
(3, 'erererwre'),
(4, 'errewre'),
(5, '5');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_transaction`
--

CREATE TABLE `tbl_session_transaction` (
  `def_pat_id` int(20) NOT NULL,
  `admitting_physician` varchar(100) NOT NULL,
  `attending_physician` varchar(100) NOT NULL,
  `deficiencies_id` varchar(200) NOT NULL,
  `room_id` varchar(50) NOT NULL,
  `hosp_patient_no` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `overall_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attending`
--
ALTER TABLE `attending`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dateme`
--
ALTER TABLE `dateme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deficiency`
--
ALTER TABLE `deficiency`
  ADD PRIMARY KEY (`deficiency_id`);

--
-- Indexes for table `deficiency_patient_details`
--
ALTER TABLE `deficiency_patient_details`
  ADD PRIMARY KEY (`def_pat_id`);

--
-- Indexes for table `deficiency_patient_details2`
--

--
-- Indexes for table `deficiency_status`
--
ALTER TABLE `deficiency_status`
  ADD PRIMARY KEY (`deficiency_status_id`),
  ADD KEY `deficieny_patient_id` (`deficiencies_id`),
  ADD KEY `deficiency_id` (`deficiency_id`);

--
-- Indexes for table `doctor_details`
--
ALTER TABLE `doctor_details`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `patient_details`
--
ALTER TABLE `patient_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_details2`
--

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `tbl_administrator`
--
ALTER TABLE `tbl_administrator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sessiondeficiency`
--
ALTER TABLE `tbl_sessiondeficiency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_session_transaction`
--
ALTER TABLE `tbl_session_transaction`
  ADD PRIMARY KEY (`def_pat_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attending`
--
ALTER TABLE `attending`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dateme`
--
ALTER TABLE `dateme`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `deficiency`
--
ALTER TABLE `deficiency`
  MODIFY `deficiency_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `deficiency_patient_details`
--
ALTER TABLE `deficiency_patient_details`
  MODIFY `def_pat_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `deficiency_patient_details2`
--
ALTER TABLE `deficiency_patient_details2`
  MODIFY `def_pat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `deficiency_status`
--
ALTER TABLE `deficiency_status`
  MODIFY `deficiency_status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `doctor_details`
--
ALTER TABLE `doctor_details`
  MODIFY `doctor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `patient_details`
--
ALTER TABLE `patient_details`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_administrator`
--
ALTER TABLE `tbl_administrator`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_sessiondeficiency`
--
ALTER TABLE `tbl_sessiondeficiency`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_session_transaction`
--
ALTER TABLE `tbl_session_transaction`
  MODIFY `def_pat_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `deficiency_patient_details2`
--


--
-- Constraints for table `deficiency_status`
--

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
