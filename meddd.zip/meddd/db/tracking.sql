-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2019 at 04:31 AM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tracking`
--

-- --------------------------------------------------------

--
-- Table structure for table `dateme`
--

CREATE TABLE `dateme` (
  `id` int(12) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `deficiency`
--

CREATE TABLE `deficiency` (
  `deficiency_id` int(11) NOT NULL,
  `deficiency_name` varchar(535) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deficiency`
--

INSERT INTO `deficiency` (`deficiency_id`, `deficiency_name`) VALUES
(1, 'No IV Fluid Sheet'),
(2, 'Nurses Notes - No Nurse Signature'),
(3, 'No Vital Signs'),
(4, 'No Vital Signs Graphic Chart'),
(5, 'Clinical Coversheet - No AP Signature'),
(6, 'Clinical Coversheet - No Diagnosis'),
(7, 'Clinical History & Physical Examination-No AP Signature'),
(8, 'Clinical History & Physical Examination-No Admitting Diagnosis'),
(9, 'Doctor\'s Order-No AP Signature'),
(10, 'Doctor\'s Order-No CounterSign by Nurse'),
(11, 'Doctor\'s Order-Incomplete Discharge Plan'),
(12, 'No Mediation Record sheet-No Specimen Signs'),
(13, 'Incomplete Discharge Summary - No course in the ward'),
(14, 'Incomplete Discharge Summary - No final Diagnosis'),
(15, 'Incomplete Discharge Summary - No AP Signature');

-- --------------------------------------------------------

--
-- Table structure for table `deficiency_patient_details`
--

CREATE TABLE `deficiency_patient_details` (
  `def_pat_id` int(20) NOT NULL,
  `admitting_physician` varchar(100) NOT NULL,
  `attending_physician` varchar(100) NOT NULL,
  `deficiencies_id` varchar(200) NOT NULL,
  `room_id` varchar(50) NOT NULL,
  `hosp_patient_no` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `overall_status` varchar(255) NOT NULL,
  `id_trick` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `doctor_details`
--

CREATE TABLE `doctor_details` (
  `doctor_id` int(11) NOT NULL,
  `doctor_name` varchar(255) NOT NULL,
  `specialization` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_details`
--

INSERT INTO `doctor_details` (`doctor_id`, `doctor_name`, `specialization`) VALUES
(20, 'Aban, Laurenz Mikhail', 'Surgery'),
(21, 'Panayaman, Alimudin K.', 'Surgery'),
(22, 'Barsanalina, Steve R.', 'Surgery'),
(23, 'Maravilla, Rolando', 'Surgery'),
(24, 'Cariño, Rosalito R. ', 'Surgery'),
(25, 'Mabanglo, Paolo Miguel, MD', 'Medical'),
(26, 'Rodriguez, Santa, MD', 'Medical'),
(27, 'Florez, Marizel O., MD', 'Medical'),
(28, 'Santos, Jose Carlo, MD', 'Medical'),
(29, 'Balmes, Bellie P., MD', 'OB'),
(31, 'Alcaide, Charlie B., MD', 'OB'),
(32, 'Alaria, Hazel Jay, MD', 'OB'),
(33, 'Umadhay, Junama Y., MD', 'OB'),
(34, 'Arpas, Maria Delilah, MD', 'Pedia'),
(35, 'Oserio, Ma. Myrna, MD', 'Pedia'),
(36, 'Calunsas, John D., MD', 'Pedia');

-- --------------------------------------------------------

--
-- Table structure for table `patient_details`
--

CREATE TABLE `patient_details` (
  `id` int(20) NOT NULL,
  `hosp_patient_no` varchar(20) NOT NULL,
  `patient_name` varchar(100) NOT NULL,
  `discharged_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` int(11) NOT NULL,
  `room_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `room_name`) VALUES
(1, 'Military Ward'),
(2, 'Payward'),
(3, 'Pediatric'),
(4, 'Obstetric'),
(5, 'OB/Gyne'),
(6, 'Surgical'),
(7, 'ICU'),
(8, 'NICU-Well Baby'),
(9, 'NICU-Non Pathologic'),
(10, 'NICU-Pathologic'),
(11, 'Septic Neonate'),
(12, 'BBS-Non Pathologic'),
(13, 'BBS-Well Baby'),
(14, 'Medical');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_administrator`
--

CREATE TABLE `tbl_administrator` (
  `id` int(12) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_administrator`
--

INSERT INTO `tbl_administrator` (`id`, `username`, `password`) VALUES
(1, 'administrator', 'administrator');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sessiondeficiency`
--

CREATE TABLE `tbl_sessiondeficiency` (
  `id` int(12) NOT NULL,
  `deficiencyX` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_transaction`
--

CREATE TABLE `tbl_session_transaction` (
  `def_pat_id` int(20) NOT NULL,
  `admitting_physician` varchar(100) NOT NULL,
  `attending_physician` varchar(100) NOT NULL,
  `deficiencies_id` varchar(200) NOT NULL,
  `room_id` varchar(50) NOT NULL,
  `hosp_patient_no` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `overall_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dateme`
--
ALTER TABLE `dateme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deficiency`
--
ALTER TABLE `deficiency`
  ADD PRIMARY KEY (`deficiency_id`);

--
-- Indexes for table `deficiency_patient_details`
--
ALTER TABLE `deficiency_patient_details`
  ADD PRIMARY KEY (`def_pat_id`);

--
-- Indexes for table `doctor_details`
--
ALTER TABLE `doctor_details`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `patient_details`
--
ALTER TABLE `patient_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `tbl_administrator`
--
ALTER TABLE `tbl_administrator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sessiondeficiency`
--
ALTER TABLE `tbl_sessiondeficiency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_session_transaction`
--
ALTER TABLE `tbl_session_transaction`
  ADD PRIMARY KEY (`def_pat_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dateme`
--
ALTER TABLE `dateme`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `deficiency`
--
ALTER TABLE `deficiency`
  MODIFY `deficiency_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `deficiency_patient_details`
--
ALTER TABLE `deficiency_patient_details`
  MODIFY `def_pat_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT for table `doctor_details`
--
ALTER TABLE `doctor_details`
  MODIFY `doctor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `patient_details`
--
ALTER TABLE `patient_details`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_administrator`
--
ALTER TABLE `tbl_administrator`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_sessiondeficiency`
--
ALTER TABLE `tbl_sessiondeficiency`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_session_transaction`
--
ALTER TABLE `tbl_session_transaction`
  MODIFY `def_pat_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
