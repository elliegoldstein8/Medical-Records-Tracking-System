<?php

$conn = new mysqli('localhost','root','','tracking');

if(ISSET($_GET['idx'])){
	
	$id = $_GET['idx'];
	$conn->query("delete from deficiency_patient_details where id_trick = '$id'");
$conn->query("delete from tbl_session_transaction");
echo "<script>window.location='reg.php'</script>";	
}
?>