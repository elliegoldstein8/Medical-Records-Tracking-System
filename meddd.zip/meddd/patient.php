<?php 	
include('session.php');
	?>
	
<?php
$conn = mysqli_connect("localhost", "root", "", "tracking");
$conn->query("delete from tbl_session_transaction");
 
?>

<html>
<head>
<meta charset="UTF-8">
  <title>Medical Records</title>
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <script  src="js/index.js"></script>
      <link rel="stylesheet" href="css/style1.css?d=<?php echo time(); ?>">
	   <script src= "searchtable.js"></script>
	   <script src="sorttable.js" type="text/javascript"></script>


</head>
<body>
<h1 style="font-family:verdana; font-weight: bold;"> Dr. Jorge P. Royeca City Hospital</h1>
<h2 style="font-family:verdana; font-weight: bold;">Medical Records</h2>
<div>
			<table>
				
					
						<font size="4px"> 
							<a href="reg">ENCODE</a> 
							<a href="track">TRACK</a>  
							<a href="Reports">REPORT</a>
                            <a href="settings">SETTINGS</a>
							  <a href="patient" style ="background-color:green;color:#fff;padding:2px 10px 2px">PATIENT LIST</a>
								<a href="logout.php">LOGOUT</a>
						</font>
				</table>
		</div>
	


  <section class="section">
	<h1>Charts Tracker</h1>
	<p>
					<input id="search-field" style="height: 30px; font-size: 18px; width: 350px;":type="text" name="search" placeholder="Search" onkeyup="myFunction()"/>
 </p>

<table id = "tableu" class="flat-table sortable">
    <thead>
        <tr>
		   <th>Hospital No.</th>
            <th>Patient Name</th>
			<th>Manage Deficiencies</th>
        </tr>
    </thead>
    <tbody>
	
	<?php

	 $sql=$conn->query("select * from  patient_details ");
	 while($row1=$sql->fetch_array()){
	
	?>
        <tr>
            <td><?php
			
			date_default_timezone_set('Asia/Manila');
	
            echo $row1['hosp_patient_no'];
      ?></td>
            <td><?php echo $row1['patient_name'];?></td>
           
			<td><a href="TrackDeficiency.php?edit=<?php echo $row1['hosp_patient_no']; ?>"><font color="1c8ae0">Track </font></a></td>
        </tr>
		 <?php
        }
        ?>

    </tbody>
</table>
  
	
</section>


</body>
</html>