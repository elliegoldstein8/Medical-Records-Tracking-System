<?php 
 $conn= mysqli_connect("localhost", "root", "", "tracking");

?>

<html>
<head>
<meta charset="UTF-8">
  <title>Medical Records</title>
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
 
   <script language="JavaScript"  src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
 <link rel= "stylesheet" href = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
 
 <script src = "https://code.jquery.com/jquery-1.12.4.js"> </script>
 <script src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


    <script  src="js/index.js"></script>
      <link rel="stylesheet" href="css/style.css">
	  <script>
  $(function(){
   $("#doctor_input").autocomplete({
   source: 'searchdoctor.php',
  });
  });
  </script>
   <meta name="viewport" content="width=device-width, initial-scale=1">


</head>
<body>

	
<script type="text/javascript">
$(document).ready(function(){    
    //Check if the current URL contains '#'
    if(document.URL.indexOf("#")==-1){
        // Set the URL to whatever it was plus "#".
        url = document.URL+"#";
        location = "#";

        //Reload the page
        location.reload(true);
    }
});
</script>

  <section class="section">
  <img src="gensan.png" style="width:250px;height:100px;" alt="Magandang Gensan!">
	<h1>ADMINISTRATOR LOGIN FORM</h1>
	<h2 style = "padding-top: 25px;"></h2>
	<form method="POST" action="" >

	<input id="" name = "username" oninvalid="this.setCustomValidity('Please Enter Username')" oninput="setCustomValidity('')" style="font-size: 18px; height: 40px; width: 350px;text-align:center;" type="text" placeholder="Enter Username"  required/>
<br>
<br>
<br>
<br>
	<input id="" name = "password" oninvalid="this.setCustomValidity('Please Enter Password')" oninput="setCustomValidity('')" style="font-size: 18px; height: 40px; width: 350px;text-align:center" type="password" placeholder="Enter Password"  required/>

 </p>


 <div class="buttons">

						<button type="submit" name="loginUser" style = "margin-left:200px;background-color:green;cursor:pointer" class="btn">LOGIN</button>
				</div>
					</form>
					
					
					<?php
					
					
	//------------------ADMINISTRATOR LOGIN CODE WITH SESSION-------------------------------//				
				if(ISSET($_POST['loginUser'])){

				$logUser = mysqli_real_escape_string($conn,$_POST['username']);
				$logPass =  mysqli_real_escape_string($conn,$_POST['password']);
				$sql=$conn->query("select * from tbl_administrator where username = '$logUser' and password = '$logPass' ");
				$rowSecurity=$sql->fetch_array();
				$id = $rowSecurity['id'];
				if($rowSecurity>0){
				session_start();
				$_SESSION['id']= $id;
					echo "<script>alert('LOGIN SUCCESSFULLY');window.location='reg'</script>";
				}else{
					
						echo "<script>alert('INVALID USERNAME OR PASSWORD');window.location='#'</script>";
					
				}

				}					
					
					
					?>

</body>
</html>