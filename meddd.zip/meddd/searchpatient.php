<?php
//Database Configuration

$mysqli = mysqli_connect("localhost", "root", "","tracking") or die ("Database Error");

$getData = $_GET['term'];
$query = $mysqli -> query ("SELECT patient_name FROM patient_details WHERE patient_name LIKE '%".$getData."%'");
while ($row = $query -> fetch_assoc()){
$data[] = $row['patient_name'];
}
echo json_encode($data);

?>