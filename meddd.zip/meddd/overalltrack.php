<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Dr. Jorge P. Royeca Hospital</title>
  

  
     
 <link rel="stylesheet" href="css/style.css">

</head>
<body>

<h1 style="font-size: 25px;"><center>Audit Deficiency Report</center></h1>
					<h3><center>January 1-31, 2019</h3>  </center>
					<table class="flat-table">
  <tbody>
    <tr>
      <th>Deficiency</th>
      <th>Medical</th>
      <th>Payward</th>
      <th>OB Gyne</th>
      <th>Military</th>
    </tr>
    <tr>
      <td>Nurses Notes</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>IV Fluid</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
  </tbody>
	</table>

					
<button onclick="javascript:history.go(-1)" style = "margin-left: 500px;
margin-top: 50px;";> BACK </button>




</body>
</html>