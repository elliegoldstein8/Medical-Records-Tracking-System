  <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowDiag=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>