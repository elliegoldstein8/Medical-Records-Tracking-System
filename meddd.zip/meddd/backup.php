<?php include('functions.php');
 $db = mysqli_connect("localhost", "root", "", "charts_tracking");
 $query = "SELECT * FROM patient_details";
 $result = mysqli_query($db, $query);
?>

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Dr. Jorge P. Royeca Hospital</title>
  

  
  <link rel="stylesheet" href="css/stylereport.css?d=<?php echo time(); ?>">

</head>
<body>

<h1 style="font-size: 25px; font-family:verdana;"><center>Audit Deficiency Monthly Report</center></h1>
					<h3 style = "font-family:verdana;"><center><?php  echo date ('M d, Y-', strtotime($month_date)); echo date ('M d, Y', strtotime($monthly_date)); ?></h3>  </center>
					<table  style = "margin-left: 30px;" class="flat-table">
  <tbody>
   
    <tr>
      <th>Deficiency</th>
      <th>Medical</th>
      <th>Pediatric</th>
      <th>Payward</th>
      <th>Obstetric</th>
      <th>OB/Gyne</th>
      <th>Surgical</th>
      <th>Military</th>
      <th>ICU</th>
      <th>NICU-Well Baby</th>
      <th>NICU-Non Pathologic</th>
      <th>NICU-Pathologic</th>
      <th>Septic Neonate</th>
      <th>BBS-Non Pathologic</th>
      <th>BBS-Well Baby</th>
    </tr>

    <?php
      $sql = $db->query("select * from deficiency");
     ?>


  <!---------------------------------------------------------------------------------->
 <tr>
      <td><b><li>Clinical coversheet</b></li></td>
   
     
    </tr>
<!---------------------------------------------------------------------------------->
 <tr>
      <td>- No AP Signature</td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>
<!---------------------------------------------------------------------------------->
 <tr>
      <td>- No Diagnosis</td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>
	<!--------------------------------------------------------------------------------->
  <tr>
      <td><b><li>Clinical History & Physical Examination</li></b></td>
   
     
    </tr>

<!--------------------------------------------------------------------------------->
  <tr>
      <td>- No AP Signature</td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>

    <tr>
      <td>- No Admitting Diagnosis</td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>

<!--------------------------------------------------------------------------------->
  <tr>
      <td><li>No Vital Signs</li></td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>
	<!--------------------------------------------------------------------------------->
  <tr>
      <td><li>No Vital Signs Graphic Chart</li></td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>
		<!--------------------------------------------------------------------------------->
  <tr>
      <td><b><li>Doctor's Order</li></b></td>
 
     
    </tr>

	<!--------------------------------------------------------------------------------->
  <tr>
 
      <td>- No AP Signature</td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>
		<!--------------------------------------------------------------------------------->
  <tr>
      <td>- No CounterSign by Nurse</td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>
		<!--------------------------------------------------------------------------------->
  <tr>
      <td>- Incomplete Discharge Plan</td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>
		<!--------------------------------------------------------------------------------->
  <tr>
      <td><li>No Mediation Record sheet - No Specimen Signs</li></td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>
		<!--------------------------------------------------------------------------------->
  <tr>
      <td><li>Nurses Notes - No Nurse Signature</li></td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>
		<!--------------------------------------------------------------------------------->
  <tr>
      <td><li>No IV fluid Sheet</li></td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>
	
		<!--------------------------------------------------------------------------------->
  <tr>
      <td><li>Incomplete Discharge Summary - No course in the ward</li></td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>
				<!--------------------------------------------------------------------------------->
  <tr>
      <td><b>Incomplete Discharge Summary</b></td>

     
    </tr>
			
			<!--------------------------------------------------------------------------------->
  <tr>
      <td>- No final Diagnosis</td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>
			<!--------------------------------------------------------------------------------->
  <tr>
      <td>- No AP Signature</td>
      <td>3</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
       <td>2</td>
      <td>1</td>
     
    </tr>
  </tbody>
	</table>


					
<button onclick="javascript:history.go(-1)" style = "margin-left: 750px;
margin-top: 50px;";> BACK </button>




</body>
</html>