<?php
	include('session.php');
 include('functions.php');
 $conn = mysqli_connect("localhost", "root", "", "tracking");
?>
<!DOCTYPE html>
<html>
<head>
 <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
 
   <script language="JavaScript"  src="js/jqueryDhatz.min.js"></script>
 <link rel= "stylesheet" href = "css/jqueryDhatz-ui.css">
 


    <script  src="js/index.js"></script>

</head>

<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}

</style>
</head>
<body>








<div class="main">








<!---------------------------------------------------------------------------------------------->
  
<a href="#admitting" class="overlay" id="admitting"></a>

<div class="popup" style="margin-top:40px;width:80%;margin-top:10px;height:90%"> 
<center><h2 style ="margin-bottom:-10px;margin-top:-10px;">ENCODING FORM</h2></center>
<section style ="float:left;">
<hr>
<center><h3>Add Patient Details</h3></center>
<hr>
<br>

<div style ="text-align:left;">

  
    <div style ="text-align:center;">
  <form action ="addPhysician.php" method = "POST" >
<label for="address1">Patient No:</label>
<input type="text"  name="patientNo" id= "patients" class='txt'  oninvalid="this.setCustomValidity('Please Input Patient number here')" oninput="setCustomValidity('')" required/>
</div>

  <div style ="text-align:center;">
  <form action ="addPhysician.php" method = "POST" >
<label for="address1">Patient Fullname:</label>
<input type="text"  name="patient"  id="patient" class='txt' oninvalid="this.setCustomValidity('Please Enter Patient Fullname')" oninput="setCustomValidity('')"  required/>
</div>
  <div style ="text-align:center;">
  <form action ="addPhysician.php" method = "POST" >
<label for="address1">Discharge Date:</label>
<input type="date"  name="date"  class='txt'  required/>
</div>
 <hr>
 <li style ="font-weight:bold;text-align:center;background-color:gray">Add Admitting Physician:</li>
 <hr>
  <div style ="text-align:center;">
  
  <form action ="addPhysician.php" method = "POST" >
<label for="address1">Admitting Physician:</label>
<input type="text"  name="physicianAdd" id='doctor_inputX' class='txt'  required/>
</div>
</div>
<div>
 <hr>
 <li style ="font-weight:bold;text-align:center;background-color:green">Add room:</li>
 <hr>
<div style ="text-align:center;">

<label><b>Room</b></label>

<select name ="roomADD" required>
<option value = ""></option>
<?php $sql = $conn->query("SELECT * from room");
		while($row=$sql->fetch_array()){ ?>
<option value = "<?php echo $row['room_id']; ?>"><?php echo $row['room_name']; ?></option>
		<?php  } ?>
</select>
</div>

	  <script>
  $(function(){
   $("#deficiencyX").autocomplete({
   source: 'searchdeficiency.php',
  });
  });
  </script>
   	  <script>
  $(function(){
   $("#doctor_inputX").autocomplete({
   source: 'searchdoctor.php',
  });
  });
  </script>
  
<!---<div style ="text-align:center;">
<label for="address1">Defficiencies:</label>
<input type="text"  name="diffeciency" id='deficiencyX' class='txt' >
</div>--->




</div>

<br>


</section>
<section style ="float:right;">
<hr>
<center><h3>Add Attending Physician</h3></center>
<hr>
<br>

<div style ="text-align:left;">
 	  <script>
  $(function(){
   $("#doctor_inputX").autocomplete({
   source: 'searchdoctor.php',
  });
  });

  $(function(){
   $("#p1").autocomplete({
   source: 'searchdoctor.php',
  });
  });

  $(function(){
   $("#p2").autocomplete({
   source: 'searchdoctor.php',
  });
  });

  $(function(){
   $("#p3").autocomplete({
   source: 'searchdoctor.php',
  });
  });

  $(function(){
   $("#p4").autocomplete({
   source: 'searchdoctor.php',
  });
  });

 $(function(){
   $("#p5").autocomplete({
   source: 'searchdoctor.php',
  });
  });

  </script>
  <div style ="text-align:center;">

  
<div style ="text-align:center;">
<label for="address1">Physician 1:</label>
<input type="text"  name="p1" id = "p1" class='txt' >
</div>
<br>
<div style ="text-align:center;">
<label for="address1">Physician 2:</label>
<input type="text"  name="p2" id ="p2"  class='txt' >
</div>
<br>
<div style ="text-align:center;">
<label for="address1">Physician 3:</label>
<input type="text"  name="p3" id ="p3" class='txt' >
</div>

<br>
<div style ="text-align:center;">
<label for="address1">Physician 4:</label>
<input type="text"  name="p4" id ="p4" class='txt' >
</div>

<br>
<div style ="text-align:center;">
<label for="address1">Physician 5:</label>
<input type="text"  name="p5" id ="p5" class='txt' >
</div>



</div>

<br>

<div id = "divD" style ="text-align:right;margin-right:50px;float:right;">
<input type ="submit" STYLE ="width:30%;background-color:green;color:#fff;font-size:20px;border:none;height:50px;width:400px;cursor:pointer;" name = "sessionme" value ="NEXT">

</form>
</div>
</section>

<a class="close" href="reg"></a>

</div>

<!---------------------------------------------------------------------------------------------->
  <style>
  .overlay{
-webkit-column-count: 3; /* Chrome, Safari, Opera */
    -moz-column-count: 3; /* Firefox */
    column-count: 3;
    -webkit-column-gap: 40px; /* Chrome, Safari, Opera */
    -moz-column-gap: 40px; /* Firefox */
   	background: rgba(0,0,0,0.3) none repeat scroll 0 0;
    margin: 0 auto;
    max-width: 95%;
	padding:40px 40px 0;
  text-align: center;
	position:relative;
  }
  </style>
<a href="#deficiency" class="overlay" id="deficiency"></a>
 
<div class="popup" style="margin-top:10px;width:50%;height:95%"> 
<section style ="float:center;">
<center><h2>Add Deficiencies</h2></center>

<br>

<?php  $sqlQQQ = $conn->query("select * from tbl_session_transaction");
		$rowQQQ = $sqlQQQ->fetch_array();
?>



<div style ="text-align:left;">
 	  <script>
  $(function(){
   $("#doctor_inputX").autocomplete({
   source: 'searchdoctor.php',
  });
  });
  </script>
  


  <form action ="addDeficiency.php" method = "POST" >
   <?php // $sqlQQx = $conn->query("select * from tbl_session_transaction");
		//$rowQQx= $sqlQQx->fetch_array();
		
		//if($rowQQx==null){
		//	 echo"<script>window.location='reg.php#admitting'</script>";
		//}
?>
<input type="text" style ="display:none" value="<?php echo $rowQQQ['admitting_physician'];?>" name="admitting">
<input type="text" style ="display:none" value="<?php echo $rowQQQ['attending_physician'];?>" name="attending">
<input type="text" style ="display:none" value="<?php echo $rowQQQ['room_id'];?>" name="room_id">
<input type="text" style ="display:none" value="<?php echo $rowQQQ['date'];?>" name="date">
<input type="text" style ="display:none" value="<?php echo $rowQQQ['hosp_patient_no'];?>" name="patientNo">
<input type="text" style ="display:none" value="<?php echo $rowQQQ['def_pat_id'];?>" name="idTrick">


	  <script>
  $(function(){
   $("#deficiencyX").autocomplete({
   source: 'searchdeficiency.php',
  });
  });
  </script>
  
<div style ="text-align:center;">
<label for="address1">Deficiencies:</label>
<input type="text"  name="diffeciency" id='deficiencyX' class='txt' required >
</div>









<br>

<div id = "divD" style ="text-align:right;margin-right:50px;float:right;">
<input type ="submit" STYLE ="width:30%;background-color:green;color:#fff;font-size:20px;border:none;height:50px;width:400px;cursor:pointer;" name = "session" value ="ADD DEFICIENCY">

</form>
</div>

<form action="destroy.php" method = "POST">
<div id = "divD" style ="text-align:right;margin-right:50px;float:right;">
<input type ="submit" STYLE ="width:30%;background-color:red;color:#fff;font-size:20px;border:none;height:50px;width:400px;cursor:pointer;" name = "session" value ="DONE">
</form>

<hr>


 <?php  $sqlJoin2 = $conn->query("select * from tbl_session_transaction inner join deficiency_patient_details on tbl_session_transaction.def_pat_id = deficiency_patient_details.id_trick");
 $rowH = $sqlJoin2->fetch_array();
 

 
 ?>
 <h2 style ="text-align:center;display:<?php if($rowH==null){ echo "none";}else{ echo "block";} ?>;">Review Information</h2>

<?php if($rowH==null){
	echo "<h2 style ='text-align:center;font-size:20px;'><i>No deficiency added yet !</i></h2>";
}
	?>
  <tr>
    <?php  $sqlJoin = $conn->query("select * from tbl_session_transaction inner join deficiency_patient_details on tbl_session_transaction.def_pat_id = deficiency_patient_details.id_trick inner join deficiency on deficiency_patient_details.deficiencies_id = deficiency.deficiency_id inner join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id");
		while($rowJ = $sqlJoin->fetch_array()){
		
?>
<hr><li style ="font-size:14px;">
   <?php  echo $rowJ['deficiency_name']; ?><?php  echo $rowJ['deficiency_name']; ?>
   <a href = "removeDefSession.php<?php echo '?idx='.$rowJ['def_pat_id'] ?>" onclick="return confirm('Do you want to remove <?php  echo $rowJ['deficiency_name']; ?> from the list?');" >remove</a>
   
 <hr>
		<?php
		}	?>


</div>



 <?php  $sqlJoin3 = $conn->query("select * from tbl_session_transaction");
 $xxx = $sqlJoin3->fetch_array();
 
 $idmo = $xxx['def_pat_id'];
 ?>

<form action="ext.php<?php echo '?idx='.$idmo; ?>" method = "POST">
<div id = "divD" style ="text-align:right;margin-right:50px;float:right;">
<input type ="submit" STYLE ="width:30%;background-color:#269ECE;color:#fff;font-size:20px;border:none;height:50px;width:400px;cursor:pointer;" name = "session" onclick = "return confirm('Do you want to cancel encoding  data?');" value ="CANCEL DATA ENCODING !!">
</form>
</section>



</div>

<br>
</div>

<style>




a#login_pop:hover, a#join_pop:hover {

border-color: #eee;

}
.panels {
	font: 1.2em normal arial;


background-color:transparent;

height: 34px;
width:40%;
padding: 10px;


}

.panels a#login_pop, .panel a#join_pop {

border: 1px solid #aaa;

color: black;

display: block;

float: right;

margin-right: 10px;

padding: 5px 10px;
text-decoration: none;

text-shadow: 1px 1px #000;

-webkit-border-radius: 10px;

-moz-border-radius: 10px;

-ms-border-radius: 10px;

-o-border-radius: 10px;

border-radius: 10px;

}

a#login_pop:hover, a#join_pop:hover {

border-color: #eee;

}
.overlay {

background-color: rgba(0, 0, 0, 0.6);

bottom: 0;

cursor: default;

left: 0;


opacity: 0;

position: fixed;
right: 0;

top: 0;

visibility: hidden;

z-index: 1;

-webkit-transition: opacity .5s;

-moz-transition: opacity .5s;

-ms-transition: opacity .5s;

-o-transition: opacity .5s;

transition: opacity .5s;

}

.overlay:target {

visibility: visible;

opacity: 1;

}
.popup-input[type=text]{
	height:60px;	
		text-align: center;
}


.popup {

background-color: #1dabf9;
font-size:20px;


display: inline-block;

left: 50%;

opacity: 0;

padding: 15px;
position: fixed;
text-align: justify;
top: 100% ;
visibility: hidden;

z-index: 10;

-webkit-transform: translate(-50%, -50%);

-moz-transform: translate(-50%, -50%);

-ms-transform: translate(-50%, -50%);

-o-transform: translate(-50%, -50%);

transform: translate(-50%, -50%);

-webkit-border-radius: 10px;

-moz-border-radius: 10px;

-ms-border-radius: 10px;




}

.overlay:target+.popup {

top: 50%;
width:40%;
opacity: 1;

visibility: visible;
background-color:#fff;
width:70%;
height:80%;

}

.close {

background-color:black;

height: 30px;

line-height: 30px;

position: absolute;

right: 0;

text-align: center;

text-decoration: none;

top: -15px;

width: 30px;
-webkit-border-radius: 15px;

-moz-border-radius: 15px;

-ms-border-radius: 15px;

-o-border-radius: 15px;

border-radius: 15px;	

}

.close:before {

color: white;

content: "X";

font-size: 24px;

text-shadow:black;

}

.close:hover {

background-color: #1dabf9;

}

.popup p, .popup div {

margin-bottom: 10px;

}

.popup label {

display: inline-block;

text-align: left;

width: 120px;

}
</style>
	
<div class="topnav">
  <a class="active" href="reg">Encode</a>
  <a href="reports1">Report</a>
    <a href="deficiencyList">Deficiency</a>
	  <a href="patientList">Patient List</a>
	   <a href="settings1">Settings</a>
	 <a href="logout.php" style="float:right;background-color:red">Logout</a>
</div>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>



</body>
</html>

  
<meta name="viewport" content="width=device-width, initial-scale=1">
   <!---<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
 
   <script language="JavaScript"  src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
 <link rel= "stylesheet" href = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
 
 <script src = "https://code.jquery.com/jquery-1.12.4.js"> </script>-->
 <script src = "js/jquery-ui.js"></script>
<style>
input.txt,select{
color: #00008B;
background-color: #E3F2F7;
border: 1px inset #00008B;
width: 350px;
height:35px;
}
input.btn {
color: #00008B;
background-color: #ADD8E6;
border: 1px outset #00008B;
height:40px;
width:140px;
margin-right:200px;
float:right;
}
form div {
clear: left;
margin: 0;
padding: 0;
padding-top: 5px;
}
form div label {
float: left;
width: 40%;
font: bold 0.9em Arial, Helvetica, sans-serif;
}
fieldset {
border: 1px dotted #61B5CF;
margin-top: 1.4em;
padding: 0.6em;
}
legend {
font: bold 0.8em Arial, Helvetica, sans-serif;
color: #00008B;
background-color: #FFFFFF;
}

</style>



<?php $conn = new mysqli('localhost','root','','tracking'); ?>
<body >

	  <script>
  $(function(){
   $("#patient").autocomplete({
   source: 'searchpatient.php',
  });
  });
  </script>

  

<br>
<br>

<!---------------------------------------------------------------->
<center>
<h1>Dr. Jorge P. Royeca City Hospital</h1>
<h2>Charts Reporting System</h2>
<img src="logo.jpg" alt="GSC logo">
<br>
<a href="#admitting" id="login_pop" style ="text-align:center;background-color:green;padding:10px 4px 10px;text-decoration:none;color:#fff;text-align:center;float:center;margin-left:100px;;"> &nbsp ADD DATA &nbsp  </a>
</center>


<div>
 <?php 
  $sqla=$conn->query("select * from deficiency_patient_details where hosp_patient_no='' and date = '0000-00-00'"); 
	$rowY=$sqla->fetch_array();
	
	
	
		
  ?>

<h2 style = "text-align:center;display:<?php if($rowY==0){ echo'none';}else{ echo 'block';} ?>;">Admitting Physician</h2>
<table style ="text-align:right;display:<?php if($rowY==0){ echo'none';}else{ echo 'block';} ?>;width:75%;">
  <tr>
    <th style="background-color:green;">Physician Name</th>
    <th style="background-color:green;">Room</th>
	 <th style="background-color:green;">Deficiency</th>
	  <th style="background-color:green;">Attending Physician</th>
	 <th style="background-color:green;"></th>
	
 
  </tr>
  <?php 
  $sqlQ=$conn->query("select * from doctor_details inner join deficiency_patient_details on doctor_details.doctor_id = deficiency_patient_details.admitting_physician inner join room on deficiency_patient_details.room_id = room.room_id inner join deficiency on deficiency_patient_details.deficiencies_id= deficiency.deficiency_id  where deficiency_patient_details.hosp_patient_no='' and date = '0000-00-00'"); 
	while($rowX=$sqlQ->fetch_array()){
			$idss = $rowX['def_pat_id'];
  ?>
  <tr>
    <td><?php echo $rowX['doctor_name']; ?></td>
    <td><?php echo $rowX['room_name']; ?></td>
	<td><?php echo $rowX['deficiency_name']; ?></td>
	<td><?php echo $rowX['attending_physician']; ?></td>
	<td><a href = "remove<?php echo'?ids='.$idss;?>"><img src="img/delete.png" style ="width:30px;height:30px"></a></td>
	<?php  }  ?>
  </tr>



</table>


<br>
<hr>

</fieldset>
<div>

</div>




<!-------------------------------------------------------------------------------------->

<style>
table{
	
	
	width:80%;

}

td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
  width:80%;
}
tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}
th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
body {font-family: Arial, Helvetica, sans-serif;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}#myBtn{
	height:40px;
	text-align:center;
	margin-right:-100px;
}
</style>
</head>


<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 30%;
  float:center;
  margin:auto;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>


</body>
</html>
