<?php

 $conn = mysqli_connect("localhost", "root", "", "tracking");

if(ISSET($_GET['id'])){
	
	$id = $_GET['id'];
$conn->query("delete from deficiency where deficiency_id = '$id'");

echo "<script>window.location='deficiencyList'</script>";

}
?>