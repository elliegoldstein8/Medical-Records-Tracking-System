<?php
	include('session.php');
?>
<?php
$conn = mysqli_connect("localhost", "root", "", "tracking");
$conn->query("delete from tbl_session_transaction");
 
?>
<!DOCTYPE html>
<html>
<head>
<script src="js/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>
	
<div class="topnav">
  <a class="active" href="reg">Encode</a>
  <a href="reports1">Report</a>
   <a href="deficiencyList">Deficiency</a>
		  <a href="patientList">Patient List</a>
		   <a href="settings1">Settings</a>
    <a href="logout.php" style="float:right;background-color:red">Logout</a>
</div>

</body>
</html>

  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
 
   <script language="JavaScript"  src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
 <link rel= "stylesheet" href = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
 
<html>
<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<head>

<h2>Patient List</h2>
 
<input id="myInput" type="text" placeholder="Search.." style="margin-left:100px;height:30px;width:400px;">
<br><br>

<table>
  <thead>
  <tr>
    <th>Hospital Patient No.</th>
    <th>Patient Name</th>
  </tr>
  </thead>
  <tbody id="myTable">
  <?php

	 $sql=$conn->query("select * from  patient_details ");
	 while($row1=$sql->fetch_array()){
	
	?>
  <tr>
    <td><?php
			
			date_default_timezone_set('Asia/Manila');
	
            echo $row1['hosp_patient_no'];
      ?></td>
    <td><?php echo $row1['patient_name'];?></td>

  </tr>
<?php
        }
        ?>
  </tbody>
</table>
  

</body>
</html>
