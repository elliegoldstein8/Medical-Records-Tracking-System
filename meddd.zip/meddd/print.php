<?php include('functions.php');
 $db = mysqli_connect("localhost", "root", "", "tracking");
  $conn = mysqli_connect("localhost", "root", "", "tracking");
 $query = "SELECT * FROM patient_details";
 $result = mysqli_query($db, $query);
?>

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Dr. Jorge P. Royeca Hospital</title>
  

  
  <link rel="stylesheet" href="css/stylereport.css?d=<?php echo time(); ?>">

</head>
<body style ="background-color:#121212;">
<style style="text/css">
  

</style>
<script>
// Whatever kind of mobile test you wanna do.
if (screen.width < 500) {
  
  // :hover will trigger also once the cells are focusable
  // you can use this class to separate things
  $("body").addClass("nohover");

  // Make all the cells focusable
  $("td, th")
    .attr("tabindex", "1")
    // When they are tapped, focus them
    .on("touchstart", function() {
      $(this).focus();
    });
  
}
</script>



<h1 style="font-size: 25px; font-family:verdana;color:#fff;"><center>Audit Deficiency Monthly Report</center></h1>
					<h3 style = "font-family:verdana;color:#fff"><center><?php  echo date ('Y-m-d', strtotime($month_date));echo " "; echo "to";echo " ";echo date ('Y-m-d', strtotime($monthly_date)); ?></h3>  </center>
					
					<?php

					$dateto=date('Y-m-d', strtotime($month_date));
					
					$datefrom =date('Y-m-d', strtotime($monthly_date));
					
				
					?>
					<table  style = "margin-left: 30px;" class="flat-table" id = "Report">
  <tbody>
   
    <tr>
      <th>Deficiency</th>
      <th>Medical</th>
      <th>Pediatric</th>
      <th>Payward</th>
      <th>Obstetric</th>
      <th>OB/Gyne</th>
      <th>Surgical</th>
      <th>Military</th>
      <th>ICU</th>
      <th>NICU-Well Baby</th>
      <th>NICU-Non Pathologic</th>
      <th>NICU-Pathologic</th>
      <th>Septic Neonate</th>
      <th>BBS-Non Pathologic</th>
      <th>BBS-Well Baby</th>
    </tr>

 
  <!---------------------------------------------------------------------------------->
 <tr>
      <td><b><li>Clinical coversheet</b></li></td>
   
     
    </tr>
<!---------------------------------------------------------------------------------->
 <tr>

      <td> No AP Signature</td>
	  <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as medical from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed['medical']; ?></td>
	   <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as Pediatric from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
       <td><?php echo $rowMed['Pediatric']; ?></td>
	    <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as Payward from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
       <td> <?php echo $rowMed['Payward']; ?></td>
	    <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as Obstetric from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed['Obstetric']; ?></td>
       <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as gyne from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowMed['gyne']; ?></td>
       <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as Surgical from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowMed['Surgical']; ?></td>
	     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as Military from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowMed['Military']; ?></td>
        <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as ICU from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowMed['ICU']; ?></td>
       <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as baby from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowMed['baby']; ?></td>
       <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as Pathologic from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowMed['Pathologic']; ?></td>
       <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as NonPathologic from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowMed['NonPathologic']; ?></td>
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as Neonate from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowMed['Neonate']; ?></td>
       <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as bbs from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowMed['bbs']; ?></td>
<!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as Nonbbs from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '5' and room.room_id  = '13' and date between '$dateto' and '$datefrom'");
	  $rowMed=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowMed['Nonbbs']; ?></td>
<!---------------------------------------------------------------------------------->    
    </tr>

<!---------------------------------------------------------------------------------->
 <tr>
      <td>- No Diagnosis</td>
      <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowDiag1=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag1['diag']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowDiag11=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag11['diag']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowDiag111=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag111['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowDiag12=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag12['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowDiag122=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag122['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowDiag22=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag22['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	  $rowDiag222=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag222['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowDiag3=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag3['diag']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowDiag33=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag33['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	  $rowDiag333=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag333['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowDiag4=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag4['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowDiag44=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag44['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowDiag444=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag444['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '6' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowDiag5=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowDiag5['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
	<!--------------------------------------------------------------------------------->
  <tr>
      <td style ="background-color:#33A8FF;color:#121212;"><b><li>Clinical History & Physical Examination</li></b></td>
   
     
    </tr>

<!--------------------------------------------------------------------------------->
  <tr>
      <td>- No AP Signature</td>
   <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowCli1=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli1['diag']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli2=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli2['diag']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowCli3=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli3['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowCli4=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli4['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowCli5=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli5['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowCli6=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli6['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	 $rowCli7=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli7['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowCli8=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli8['diag']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowCli9=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli9['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	 $rowCli10=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli10['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowCli11=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli11['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowCli12=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli12['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowCli13=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli13['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '7' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli14=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli14['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
<!--------------------------------------------------------------------------------------------------------------------------------------->
    <tr>
      <td style ="background-color:green;color:white;">- No Admitting Diagnosis</td>
   <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowCli1=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli1['diagx']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli2=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli2['diagx']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowCli3=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli3['diagx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowCli4=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli4['diagx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowCli5=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli5['diagx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowCli6=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli6['diagx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	 $rowCli7=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli7['diagx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowCli8=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli8['diagx']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowCli9=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli9['diagx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	 $rowCli10=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli10['diagx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowCli11=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli11['diagx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowCli12=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli12['diagx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowCli13=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli13['diagx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '8' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli14=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli14['diagx']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
<!--------------------------------------------------------------------------------------------------------------------------------------->
  <tr>
      <td><li>No Vital Signs</li></td>
 <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowCli1=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli1['diagxx']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli2=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli2['diagxx']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowCli3=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli3['diagxx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowCli4=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli4['diagxx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowCli5=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli5['diagxx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowCli6=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli6['diagxx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	 $rowCli7=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli7['diagxx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowCli8=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli8['diagxx']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowCli9=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli9['diagxx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	 $rowCli10=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli10['diagxx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowCli11=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli11['diagxx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowCli12=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli12['diagxx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowCli13=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli13['diagxx']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxx from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli14=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli14['diagxx']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
<!--------------------------------------------------------------------------------------------------------------------------------------->
  <tr>
      <td style ="background-color:green;color:white;"><li>No Vital Signs Graphic Chart</li></td>
 <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '4' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowCli1=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli1['diagxxz']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '4' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli2=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli2['diagxxz']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '4' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowCli3=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli3['diagxxz']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '4' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowCli4=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli4['diagxxz']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '4' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowCli5=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli5['diagxxz']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '4' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowCli6=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli6['diagxxz']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '3' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	 $rowCli7=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli7['diagxxz']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '4' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowCli8=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli8['diagxxz']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '4' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowCli9=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli9['diagxxz']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '4' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	 $rowCli10=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli10['diagxxz']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '4' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowCli11=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli11['diagxxz']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '4' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowCli12=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli12['diagxxz']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '4' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowCli13=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli13['diagxxz']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagxxz from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '4' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli14=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli14['diagxxz']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
<!--------------------------------------------------------------------------------------------------------------------------------------->
  <tr>
      <td style ="background-color:yellow;color:#121212;"><b><li>Doctor's Order</li></b></td>
 
     
    </tr>

	<!--------------------------------------------------------------------------------->
  <tr>
 
      <td>- No AP Signature</td>
   <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowCli1=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli1['diaga']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli2=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli2['diaga']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowCli3=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli3['diaga']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowCli4=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli4['diaga']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowCli5=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli5['diaga']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowCli6=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli6['diaga']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	 $rowCli7=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli7['diaga']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowCli8=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli8['diaga']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowCli9=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli9['diaga']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	 $rowCli10=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli10['diaga']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowCli11=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli11['diaga']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowCli12=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli12['diaga']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowCli13=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli13['diaga']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diaga from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '9' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli14=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli14['diaga']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
<!--------------------------------------------------------------------------------------------------------------------------------------->
  <tr>
      <td style ="background-color:green;color:white;">- No CounterSign by Nurse</td>
   <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowCli1=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli1['diagb']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli2=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli2['diagb']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowCli3=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli3['diagb']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowCli4=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli4['diagb']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowCli5=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli5['diagb']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowCli6=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli6['diagb']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	 $rowCli7=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli7['diagb']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowCli8=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli8['diagb']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowCli9=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli9['diagb']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	 $rowCli10=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli10['diagb']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowCli11=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli11['diagb']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowCli12=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli12['diagb']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowCli13=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli13['diagb']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagb from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '10' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli14=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli14['diagb']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
<!--------------------------------------------------------------------------------------------------------------------------------------->
  <tr>
      <td>- Incomplete Discharge Plan</td>
   <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagc from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowCli1=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli1['diagc']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagc from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli2=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli2['diagc']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagc from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowCli3=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli3['diagc']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagc from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowCli4=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli4['diagc']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagc from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowCli5=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli5['diagc']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagc from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowCli6=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli6['diagc']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagc from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	 $rowCli7=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli7['diagc']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagc from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowCli8=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli8['diagc']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diag from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowCli9=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli9['diag']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagc from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	 $rowCli10=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli10['diagc']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagc from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowCli11=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli11['diagc']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagc from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowCli12=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli12['diagc']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagc from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowCli13=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli13['diagc']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagc from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id INNER join doctor_details on deficiency_patient_details.admitting_physician = doctor_details.doctor_id where deficiency_id = '11' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli14=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli14['diagc']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
<!--------------------------------------------------------------------------------------------------------------------------------------->
  <tr>
      <td style ="background-color:green;color:white;"><li>No Mediation Record sheet - No Specimen Signs</li></td>
   <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowCli1=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli1['diagd']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli2=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli2['diagd']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowCli3=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli3['diagd']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowCli4=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli4['diagd']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowCli5=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli5['diagd']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowCli6=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli6['diagd']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	 $rowCli7=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli7['diagd']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowCli8=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli8['diagd']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowCli9=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli9['diagd']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	 $rowCli10=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli10['diagd']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowCli11=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli11['diagd']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowCli12=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli12['diagd']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowCli13=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli13['diagd']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagd from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '12' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli14=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli14['diagd']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
<!--------------------------------------------------------------------------------------------------------------------------------------->
  <tr>
      <td><li>Nurses Notes - No Nurse Signature</li></td>
   <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowCli1=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli1['diage']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli2=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli2['diage']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowCli3=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli3['diage']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowCli4=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli4['diage']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowCli5=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli5['diage']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowCli6=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli6['diage']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	 $rowCli7=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli7['diage']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowCli8=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli8['diage']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowCli9=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli9['diage']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	 $rowCli10=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli10['diage']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowCli11=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli11['diage']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowCli12=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli12['diage']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowCli13=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli13['diage']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diage from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '2' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli14=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli14['diage']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
<!--------------------------------------------------------------------------------------------------------------------------------------->
  <tr>
      <td style ="background-color:green;color:white;"><li>No IV fluid Sheet</li></td>
   <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowCli1=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli1['diagf']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli2=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli2['diagf']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowCli3=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli3['diagf']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowCli4=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli4['diagf']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowCli5=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli5['diagf']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowCli6=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli6['diagf']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	 $rowCli7=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli7['diagf']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowCli8=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli8['diagf']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowCli9=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli9['diagf']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	 $rowCli10=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli10['diagf']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowCli11=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli11['diagf']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowCli12=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli12['diagf']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowCli13=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli13['diagf']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagf from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '1' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli14=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli14['diagf']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
<!--------------------------------------------------------------------------------------------------------------------------------------->
  <tr>
      <td ><li>Incomplete Discharge Summary - No course in the ward</li></td>
   <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowCli1=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli1['diagg']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli2=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli2['diagg']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from room inner join deficiency_patient_details on room.room_id = deficiency_patient_details.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowCli3=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli3['diagg']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowCli4=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli4['diagg']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowCli5=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli5['diagg']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowCli6=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli6['diagg']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	 $rowCli7=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli7['diagg']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowCli8=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli8['diagg']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowCli9=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli9['diagg']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	 $rowCli10=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli10['diagg']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowCli11=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli11['diagg']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowCli12=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli12['diagg']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowCli13=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli13['diagg']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagg from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '13' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli14=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli14['diagg']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
<!--------------------------------------------------------------------------------------------------------------------------------------->
  <tr>
      <td style ="background-color:#E313B7;color:#fff;"><b><li>Incomplete Discharge Summary</li></b></td>

     
    </tr>
			
			<!--------------------------------------------------------------------------------->
  <tr>
      <td>- No final Diagnosis</td>
   <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowCli1=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli1['diagh']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli2=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli2['diagh']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowCli3=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli3['diagh']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowCli4=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli4['diagh']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowCli5=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli5['diagh']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowCli6=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli6['diagh']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	 $rowCli7=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli7['diagh']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowCli8=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli8['diagh']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowCli9=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli9['diagh']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	 $rowCli10=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli10['diagh']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowCli11=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli11['diagh']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowCli12=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli12['diagh']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowCli13=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli13['diagh']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagh from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '14' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli14=$sqlMedical->fetch_array();
	  ?>
      <td><?php echo $rowCli14['diagh']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
<!--------------------------------------------------------------------------------------------------------------------------------------->
  <tr>
      <td style ="background-color:green;color:white;">- No AP Signature</td>
   <!---------------------------------------------------------------------------------->	  
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '14' and date between '$dateto' and '$datefrom'");
	  $rowCli1=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli1['diagq']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli2=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli2['diagq']; ?></td>
<!----------------------------------------------------------------------------------> 
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '2' and date between '$dateto' and '$datefrom'");
	  $rowCli3=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli3['diagq']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '4' and date between '$dateto' and '$datefrom'");
	  $rowCli4=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli4['diagq']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '5' and date between '$dateto' and '$datefrom'");
	  $rowCli5=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli5['diagq']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '6' and date between '$dateto' and '$datefrom'");
	  $rowCli6=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli6['diagq']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '1' and date between '$dateto' and '$datefrom'");
	 $rowCli7=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli7['diagq']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '7' and date between '$dateto' and '$datefrom'");
	  $rowCli8=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli8['diagq']; ?></td>
<!---------------------------------------------------------------------------------->
      <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '8' and date between '$dateto' and '$datefrom'");
	  $rowCli9=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli9['diagq']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '9' and date between '$dateto' and '$datefrom'");
	 $rowCli10=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli10['diagq']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '10' and date between '$dateto' and '$datefrom'");
	  $rowCli11=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli11['diagq']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '11' and date between '$dateto' and '$datefrom'");
	  $rowCli12=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli12['diagq']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '12' and date between '$dateto' and '$datefrom'");
	  $rowCli13=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli13['diagq']; ?></td>
<!---------------------------------------------------------------------------------->
     <?php  $sqlMedical = $conn->query("select COUNT(hosp_patient_no) as diagq from deficiency_patient_details inner join room on deficiency_patient_details.room_id =room.room_id INNER join deficiency ON deficiency_patient_details.deficiencies_id = deficiency.deficiency_id where deficiency_id = '15' and room.room_id  = '3' and date between '$dateto' and '$datefrom'");
	  $rowCli14=$sqlMedical->fetch_array();
	  ?>
      <td style ="background-color:green;color:white;"><?php echo $rowCli14['diagq']; ?></td>
<!---------------------------------------------------------------------------------->
     
    </tr>
<!--------------------------------------------------------------------------------------------------------------------------------------->
  </tbody>
	</table>
	
	<script>
	var allTableCells = document.getElementsByTagName("td");

for(var i = 0, max = allTableCells.length; i < max; i++) {
    var node = allTableCells[i];
    var currentText = node.childNodes[0].nodeValue; 

    if(currentText > "0")
        node.style.backgroundColor = "#E21610";

}
	</script>


					

<script>

var tablesToExcel = (function() {
    var uri = 'data:application/vnd.ms-excel;base64,'
    , tmplWorkbookXML = '<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">'
      + '<DocumentProperties xmlns="urn:schemas-microsoft-com:office:office"><Author>Axel Richter</Author><Created>{created}</Created></DocumentProperties>'
      + '<Styles>'
      + '<Style ss:ID="Currency"><NumberFormat ss:Format="Currency"></NumberFormat></Style>'
      + '<Style ss:ID="Date"><NumberFormat ss:Format="Medium Date"></NumberFormat></Style>'
      + '</Styles>' 
      + '{worksheets}</Workbook>'
    , tmplWorksheetXML = '<Worksheet ss:Name="{nameWS}"><Table>{rows}</Table></Worksheet>'
    , tmplCellXML = '<Cell{attributeStyleID}{attributeFormula}><Data ss:Type="{nameType}">{data}</Data></Cell>'
    , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
    , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
    return function(tables, wsnames, wbname, appname) {
      var ctx = "";
      var workbookXML = "";
      var worksheetsXML = "";
      var rowsXML = "";
	  

      for (var i = 0; i < tables.length; i++) {
        if (!tables[i].nodeType) tables[i] = document.getElementById(tables[i]);
        for (var j = 0; j < tables[i].rows.length; j++) {
          rowsXML += '<Row>'
          for (var k = 0; k < tables[i].rows[j].cells.length; k++) {
            var dataType = tables[i].rows[j].cells[k].getAttribute("data-type");
            var dataStyle = tables[i].rows[j].cells[k].getAttribute("data-style");
            var dataValue = tables[i].rows[j].cells[k].getAttribute("data-value");
            dataValue = (dataValue)?dataValue:tables[i].rows[j].cells[k].innerHTML;
            var dataFormula = tables[i].rows[j].cells[k].getAttribute("data-formula");
            dataFormula = (dataFormula)?dataFormula:(appname=='Calc' && dataType=='DateTime')?dataValue:null;
            ctx = {  attributeStyleID: (dataStyle=='Currency' || dataStyle=='Date')?' ss:StyleID="'+dataStyle+'"':''
                   , nameType: (dataType=='Number' || dataType=='DateTime' || dataType=='Boolean' || dataType=='Error')?dataType:'String'
                   , data: (dataFormula)?'':dataValue
                   , attributeFormula: (dataFormula)?' ss:Formula="'+dataFormula+'"':''
				   
                  };
            rowsXML += format(tmplCellXML, ctx);
          }
          rowsXML += '</Row>'
        }
        ctx = {rows: rowsXML, nameWS: wsnames[i] || 'Sheet' + i};
        worksheetsXML += format(tmplWorksheetXML, ctx);
        rowsXML = "";
      }

      ctx = {created: (new Date()).getTime(), worksheets: worksheetsXML};
      workbookXML = format(tmplWorkbookXML, ctx);



      var link = document.createElement("A");
      link.href = uri + base64(workbookXML);
      link.download = wbname || 'Workbook.xls';
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  })();


  
  
  
</script>


</body>
</html>