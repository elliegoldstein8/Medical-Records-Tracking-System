<?php


 $conn = mysqli_connect("localhost", "root", "", "tracking");
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
</head>


  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
 
   <script language="JavaScript"  src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
 <link rel= "stylesheet" href = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
 
<html>
<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<head>

<style>
input.txt,select{
color: #00008B;
background-color: #E3F2F7;
border: 1px inset #00008B;
width: 350px;
height:35px;
}
input.btn {
color: #00008B;
background-color: #ADD8E6;
border: 1px outset #00008B;
height:40px;
width:140px;
margin-right:200px;
float:right;
}
form div {
clear: left;
margin: 0;
padding: 0;
padding-top: 5px;
}
form div label {
float: left;
width: 40%;
font: bold 0.9em Arial, Helvetica, sans-serif;
}
fieldset {
border: 1px dotted #61B5CF;
margin-top: 1.4em;
padding: 0.6em;
}
legend {
font: bold 0.8em Arial, Helvetica, sans-serif;
color: #00008B;
background-color: #FFFFFF;
}
</style>
   <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
 
   <script language="JavaScript"  src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
 <link rel= "stylesheet" href = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
 
 <script src = "https://code.jquery.com/jquery-1.12.4.js"> </script>
 <script src = "https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script  src="js/index.js"></script>

</head>
<?php $conn = new mysqli('localhost','root','','tracking'); ?>
<body >
<h1 style = "text-align:center;">Encoding form:</h1>
<label style = "text-align:center;">Feel free to fill out the form with the required information.</label>
<form method="post" action="">
<div style = "text-align:left;">
<fieldset>
<legend>Feel free to fill out the form with the required information.</legend>
<div>
	  <script>
  $(function(){
   $("#patient").autocomplete({
   source: 'searchpatient.php',
  });
  });
  </script>
<script>
  $(function(){
   $("#patients").autocomplete({
   source: 'searchID.php',
  });
  });
  </script>
  
  <div>
 <form action="" method = "POST" >
<label for="email">Hospital Patient No.:</label>
<input type="text" name="patientNo" id= "patients" class="txt" required />
</div>



  

<br>
<br>
<input type = "submit" name = "session" value="START SESSION"/>

<?php

if(ISSET($_POST['session'])){
	
	session_start();
	
	$p = $_POST['patientNo'];
	$_SESSION['patientNo'][]= $p;
	
foreach ($_SESSION['patientNo'] as $p){

	echo $p;
	echo '<br>';
}
}

?>
</form>
<br>